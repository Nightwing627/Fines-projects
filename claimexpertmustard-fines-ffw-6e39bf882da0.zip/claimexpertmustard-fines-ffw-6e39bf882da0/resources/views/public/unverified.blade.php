@extends('layouts.fines')

@section('header')
    @include('headers.unverified')
@endsection


@section('content')
<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
            <h2>Your email address has not been verified yet!</h2>

            <p>Please check your inbox for a confirmation email to continue. </p>

        </div>

    </div>


    </div>
</div>
@endsection
