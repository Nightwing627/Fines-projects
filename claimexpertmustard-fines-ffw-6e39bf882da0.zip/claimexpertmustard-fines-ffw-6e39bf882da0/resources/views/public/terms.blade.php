@extends('layouts.fines')

@section('header')
    @include('headers.legal')
@endsection


@section('content')
<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
                <h2>Terms and Conditions for Fine Expert</h2>

                <p>By registering and with and making use of the Fine.Expert service you agree to and acknowledge the following:</p>

                <ol>
                        <li>
                        Fine.Expert undertakes to use reasonable endeavours to identify and notify Members via email and/or SMS and/or telephone call of Fines issued to them provided such fines can be identified on the databases of Third Party Fines Service Providers.
                        </li>
                        <li>From time to time fines issued may not be loaded on the Third Party Fines Service Providers’ databases. The onus rests on the Member to notify Fine.Expert if he/ she becomes aware of any issued Fines. 
                        </li>
                        <li>Fines that do not offer the option of admission of guilt (“NAG”) and fines that do not state an amount are excluded from the Fine.Expert service.
                        </li>
                        <li>If Members want assistance with fines that are not identified on the Third Party Fines Service Providers’ databases, the Member has to notify Fine.Expert of such fines.
                        </li>
                        <li>Fine.Expert shall attempt to negotiate a discount of the amount of the Fine originally imposed by the applicable Authority however discounts are not guaranteed.
                        </li>
                        <li>Fine.Expert will notify the Member of the fine amount to be paid. Any quoted amounts need to be paid to Fine.Expert within 15 days after which time Fine.Expert will settle the fine with the relevant Issuing Authority and provide proof of same to the Member. Fine.Expert reserves the right to retain a portion of any discount negotiated on behalf of the member and to charge a convenience fee for the use of the Fine.Expert service and this will be communicated to the member if applicable.
                        </li>
                        <li>Only traffic fines issued in the Republic of South Africa are covered by Fine.Expert.
                        </li>
                        <li>The Fine.Expert service is limited to the Member.
                        </li>
                        <li>	In order to be entitled to the Fines Protect service a Member’s membership must be fully paid up at the time of the Fine being Issued.
                        </li>
                        <li>	At the time of the Fine you must comply with all the legal and regulatory requirements of the NRSA, the NRTA, the RTA and any other legislation pertaining to the utilisation of a public road, as defined in the NRTA, including, without limitation, any such sub-ordinate legislation, regulations and by-laws pertaining to any of the aforementioned.
                        </li>
                        <li>Fine.Expert does not guarantee the performance of any traffic department or any other Authority dealing with Fines. 
                        </li>
                        <li>	Fines Protect will take reasonable steps to obtain proof from the relevant Authority that a Fine was paid and will furnish such proof to the Member. 
                        </li>
                        <li>Any de-merit points reductions made in respect of the Administrative Adjudication of Road Traffic Offences (AARTO) Act nr 46 of 1998 is excluded from Fine.Expert.You aware of the content of the Criminal Procedure Act, Act 51 of 1977 as well as the AARTO Legislation, Act 46 of 1998 and the regulations promulgated in terms of that act.
                        </li>
                        <li>You are particularly aware and advised on Section 73 of the Road Traffic Act, which contains the presumption that the registered owner are deemed to be the driver of the vehicle except where evidence to the contrary are provided.  You are aware of and understand the content of Section 17 (5) of Act 46 of 1998, that there is a duty upon the registered owner of a vehicle to obtain the particulars of the driver if the registered owner were not the driver at any given point in time.
                        </li>
                        <li>You are also aware that in terms of the Criminal Procedure Act read with the TCSP guidelines, that a local authority must post a Section 341 to the registered owner within 30 days.  Similarly you aware that in terms of the Administrative Adjudication of Road Traffic Offences Act (AARTO) an infringement notice must be served upon registered owner as prescribed in terms of Act 46 of 1998 within a period of 40 days.
                        </li>
                        <li>You are ware that the issuing authority must send an infringement notice in terms of the AARTO Legislation or a Section 341 in terms of the Criminal Procedure Act to the registered owner, either by registered post or personal service in the case of AARTo [act 46/1998] and normal post in the case of the Criminal Procedure act. However you agree that this can be substituted with an electronic notice either via email or a secure website portal where you are notified of fines. I agree that information can be electronically be exchanged between the relevant issuing authorities or their duly appointed agents and our company’s representatives or its duly appointed agents.
                        </li>
                        <li>You also hereby confirm that you will never raise the defence that you have not received an infringement notice in terms of the AARTO Legislation and/or Section 341 notice in terms of the Criminal Procedure Act. </li>
                      </ol>


                      <h4>Detailed Description of Goods and/or Services</h4>

                      <p>Claim Expert SA (PTY) Ltd is a business in the value added services industry that markets  a suite of value added products and services to affinity groups.</p>
                            
                        
                        <h4>Delivery Policy</h4>
                        <p>Subject to availability and receipt of payment, requests will be processed within 2 working days and delivery confirmed by way of and email or indication on our customer portal.
                            </p>


                      <h4>Customer Privacy Policy </h4>

                        <p>Claim Expert SA (PTY) Ltd shall take all reasonable steps to protect the personal information of users. For the purpose of this clause, "personal information" shall be defined as detailed in the Promotion of Access to Information Act 2 of 2000 (PAIA). The PAIA may be downloaded from: 
                      http://www.polity.org.za/attachment.php?aa_id=3569</p>

                      <h4>Payment options accepted</h4>

                      <p>Payment may be made via Visa, MasterCard, credit cards or by bank transfer into the ”Your company name” bank account, the details of which will be provided on request</p>
                      
                      <h4>Credit card acquiring and security</h4>
                      <p>Credit card transactions will be acquired for Claim Expert SA (PTY) Ltd via PayGate (Pty) Ltd who are the approved payment gateway for Standard Bank South Africa.  PayGate uses the strictest form of encryption, namely Secure Socket Layer 3 (SSL3) and no credit card details are stored on the website.  Users may go to www.paygate.co.za to view their security certificate and security policy.   </p>

                      
                      <h4>Customer details separate from card details</h4>
                        <p>Customer details will be stored by ” Claim Expert SA (PTY) Ltd separately from card details which are entered by the client on PayGate’s secure site.  For more detail on PayGate refer to www.paygate.co.za 
                            </p>

                      <h4>Merchant Outlet country and transaction currency</h4>
<p>The merchant outlet country at the time of presenting payment options to the cardholder is South Africa.  Transaction Currency is South African Rand (ZAR). 
    </p>

<h4>Responsibility</h4>
<p>Claim Expert SA (PTY) Ltd takes responsibility for all aspects relating to the transaction including sale of goods and services sold on this website, customer service and support, dispute resolution and delivery of goods 
    </p>

<h4>Country of domicile</h4>
<p>This website is governed by the laws of South Africa and Claim Expert SA (PTY) Ltd chooses as its domicilium citandi et executandi for all purposes under this agreement, whether in respect of court process, notice, or other documents or communication of whatsoever nature,  86 Studio Park, Concourse Crescent, Lonehill, 2060.
    </p>

<h4>Variation</h4>
<p>Claim Expert SA (PTY) Ltd may, in its sole discretion, change this agreement or any part thereof at any time without notice.
    </p>

<h4>Company information</h4>
<p>This website is run by Claim Expert SA (PTY) Ltd based in South Africa trading as Claim Expert and with registration number 2002/022864/07 and Directors TC Case and LR de Jager.
    </p>

<h4>Claim Expert SA (PTY) Ltd - contact details</h4>
    <p>Email: info@claimexpert.co.za <br/>
    Telephone: 0860 999 916</p>



        </div>

    </div>


    </div>
</div>
@endsection
