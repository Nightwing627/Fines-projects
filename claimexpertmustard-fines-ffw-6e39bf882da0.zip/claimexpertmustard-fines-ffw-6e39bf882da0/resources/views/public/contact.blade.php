@extends('layouts.fines')

@section('header')
    @include('headers.contact')
@endsection


@section('content')
<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
                {!! Form::open(
                    array(
                        'method' => 'POST',
                        'action' => 'ContactController@store',
                        'class' => 'form form-table'))
                !!}
                    
                    <div class="form-group row">
                            <label for="first_name" class="col-md-4 col-form-label text-md-right">{{ __('First Name') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::text('first_name', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'Enter your first name...',
                                        'required',
                                        'autofocus',
                                        'id'                            => 'first_name',
                                     ]) !!}

                            </div>
                    </div>

     
                    <div class="form-group row">
                            <label for="last_name" class="col-md-4 col-form-label text-md-right">{{ __('Last Name') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::text('last_name', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'Enter your last name...',
                                        'required',
                                        'id'                            => 'last_name',
                                     ]) !!}

                            </div>
                    </div>

     
                    <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('Email') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::email('email', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'Enter your email address...',
                                        'required',
                                        'id'                            => 'email',
                                     ]) !!}

                            </div>
                    </div>

     
                    <div class="form-group row">
                            <label for="phone" class="col-md-4 col-form-label text-md-right">{{ __('Phone') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::text('phone', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'Enter your contact number...',
                                        'required',
                                        'id'                            => 'phone',
                                     ]) !!}

                            </div>
                    </div>


                    <div class="form-group row">
                            <label for="message" class="col-md-4 col-form-label text-md-right">{{ __('Message') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::textarea('message', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'Enter a message...',
                                        'required',
                                        'id'                            => 'message',
                                     ]) !!}

                            </div>
                    </div>




                    <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                        {!! Form::submit('Contact us', ['value' => 'validate', 'class' => 'btn btn-primary']) !!}
                            </div>
                        </div>
               

            {!! Form::close() !!}


        </div>

    </div>


    </div>
</div>
@endsection
