@extends('layouts.fines')

@section('header')
    @include('headers.home')
@endsection


@section('content')
<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Welcome {{ $user->name }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    Total Fines: R{{ number_format($user->fines->sum('issued_amount'),2,'.','') }} <br/>
                    <strong> Total Payable: R{{ number_format($user->fines->sum('total_payable'),2,'.','') }} </strong> <br/>
                    {{-- Total Saved: R{{ number_format($user->fines->sum('discount'),2,'.','') }}  <br/> --}}
                    <hr/>
                    Total Payments: R{{ number_format($paymentsMade,2,'.','') }}<br/>
                    {{-- <strong>Balance Outstanding: R{{ number_format($user->fines->sum('total_payable') - $paymentsMade,2,'.','') }} </strong> --}}

                    <hr/>
                    
                    <a class="btn btn-primary" href="{{ route('payment') }}" role="button">New Payment <i class="fas fa-long-arrow-alt-right"></i> </a>
                    

                </div>
            </div>
        </div>

    </div>


    </div>
</div>
@endsection
