@extends('layouts.fines')

@section('header')
    @include('headers.profile')
@endsection


@section('content')
<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">


                {!! Form::model($user,
                    ['method' => 'PATCH',
                    'name' => 'profile-updatee',
                    'id' => 'profile-update',
                    'route' => ['profile-update', $user->id],
                    'class' => 'form form-table',
                    ]) !!}
                    
                

                    <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::text('name', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'Name',
                                        'required',
                                        'autofocus',
                                        'id'                            => 'name',
                                     ]) !!}

                            </div>
                    </div>

                    
                    <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('Email') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::email('email', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'Email',
                                        'required',
                                        'id'                            => 'email',
                                     ]) !!}

                            </div>
                    </div>

       
                    <div class="form-group row">
                            <label for="id_number" class="col-md-4 col-form-label text-md-right">{{ __('ID Number') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::text('id_number', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'ID Number',
                                        'required',
                                        'id'                            => 'id_number',
                                     ]) !!}

                            </div>
                    </div>
       


                    <div class="form-group row">
                            <label for="mobile" class="col-md-4 col-form-label text-md-right">{{ __('Mobile Number') }}</label>

                            <div class="col-md-6">
                                
                                    {!! Form::text('mobile', null, [
                                        'class'                         => 'form-control',
                                        'placeholder'                   => 'Mobile Number',
                                        'required',
                                        'id'                            => 'mobile',
                                     ]) !!}

                            </div>
                    </div>
       



                    <div class="form-group row">
                            <label for="mobile" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                
                                    <input id="password" type="password" class="form-control" name="password">

                            </div>
                    </div>
       


                    <div class="form-group row">
                        <label for="notify_me" class="col-md-4 col-form-label text-md-right">{{ __('Communication') }}</label>

                        <div class="col-md-6">
                                <div class="checkbox">
                                <label class="checkbox-label">
                                        {!! Form::hidden('notify_me','0') !!}
                                        {!! Form::checkbox('notify_me','1', $user->notify_me) !!} Send me notifications
                                </label>
                                </div>
                        </div>
                   </div>



                    <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                               
                                {!! Form::submit('Update Profile', ['value' => 'validate', 'class' => 'btn btn-primary']) !!}
                         
                            </div>
                        </div>
               

                    
                {!! Form::close() !!}
                    

        </div>
    </div>

</div>

@endsection
