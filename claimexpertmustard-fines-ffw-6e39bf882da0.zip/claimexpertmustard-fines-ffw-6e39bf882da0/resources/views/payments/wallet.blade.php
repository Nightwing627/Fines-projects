@extends('layouts.fines') @section('header') @include('headers.payment') @endsection @section('content')

<div class="container">

    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
                                
                    @if($user->has_wallet) 

                        @include('payments.partials.wallet-payment')

                    @else

                        <h5 class="card-title">You Do Not have a Wallet yet </h5>
                        <p class="card-text">You can use your wallet to make payments for your fines!</p>
                        

                        <a class="btn btn-primary" id="walllet" href="{{ route('wallet-activate', $user->id) }}">
                            Activate my Wallet
                        </a>

                    @endif
 
        </div>
    </div>


</div>

@endsection