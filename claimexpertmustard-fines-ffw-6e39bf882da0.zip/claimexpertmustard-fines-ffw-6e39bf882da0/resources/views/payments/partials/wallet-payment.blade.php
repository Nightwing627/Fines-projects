<div class="card bg-light mb-3">

    <div class="card-body">
        <h5 class="card-title">Wallet Payment</h5>
        <p class="card-text">
            You have selected to make a payment of
            <strong>R{{ $payment->amount }}</strong>

            and your current wallet balance is:
                <strong>R{{ $user->wallet_balance }}.</strong>
        </p>

        <p class="card-text">
                
            </p>
    


            @if($user->wallet_balance >= $payment->amount)

            <div class="alert alert-success" role="alert">
            
               @include('wallet.process-wallet-payment')
            
            </div>

            @else

            <div class="alert alert-warning" role="alert">
                 <p> Unfortunately you do not have sufficient credit in your Wallet to make this payment. </p>
           
                  <a class="btn btn-primary" id="changePmtType" href="{{ route('payment-select', $payment->uuid) }}">
                        Change Payment Method
                  </a>

                  <span class="or-spacer"> or </span> 

                  <a class="btn btn-primary" id="changePmtType" href="{{ route('wallet-purchase') }}">
                        Buy More Credit
                  </a>

           
            </div>



            @endif


    </div>

</div>