<div class="table-hold">
 
        <table id="paymentList" class="table table-striped" cellspacing="0" width="100%">
    
          <thead>
              <tr>
                   <th><i class="fas fa-paperclip"></i> </th> 
                   <th>Date</th>
                   <th>Amount</th>
                   <th>Fines</th>
                   <th>Type</th>
                   <th>Status</th>
                   <th>Ref</th>
                   <th></th>

              </tr>
          </thead>
    
        <tbody>
    
            @foreach($user->payments as $payment)
    
                <tr>
                  <td> <a target="_blank" href="/payment/receipt/{{$payment->uuid}}"> <i class="fas fa-print"></i> </a> </td>
                 
                  <td> {{ Carbon::parse($payment->created_at)->toFormattedDateString() }} </td>
                  <td> R{{number_format($payment->amount, 2, '.', ' ') }} </td>
                  <td> @include('payments.linkedFines') </td>
                  <td> {{$payment->type->name}} </td>
                  <td> <a data-placement="right" data-toggle="tooltip" title="{{$payment->status->description}}"> {{$payment->status->name}} </a>   </td>
                  <td> {{$payment->reference}} </td>
                 
                 
                  <td> <a data-toggle="modal" data-target="#pay-{{$payment->id}}" href="#"> <i class="fas fa-long-arrow-alt-right"></i></a>  </td>
                  
                </tr>
    
            @endforeach
    
        </tbody>
    
    </table>
    
    </div>
    
    
    @foreach($user->payments as $payment)
    
    
    <div class="modal fade" id="pay-{{$payment->id}}" tabindex="-1" role="dialog" aria-labelledby="pay-{{$payment->id}}" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                
                    <div class="modal-header">
                        <h5 class="modal-title" id="pay-{{$payment->id}}Label">Payment: {{$payment->id}}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                
                    <div class="modal-body">
        
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item"><span>Payment #: </span> PMT-00{{$payment->id}}</li>
                                <li class="list-group-item"><span>ID Number: </span>{{$payment->id_number}}</li>
                                <li class="list-group-item"><span>Payment Date: </span> {{ Carbon::parse($payment->created_at)->toFormattedDateString() }}</li>
                                <li class="list-group-item"><span>Remark: </span>{{$payment->remark}}</li> 
                                <li class="list-group-item"><span>Reference: </span>{{$payment->reference}}</li>       
                                <li class="list-group-item"><span>Payment Amount: </span> R{{number_format($payment->amount, 2, '.', ' ') }}</li>
                                <li class="list-group-item"><span>Payment Status: </span> {{$payment->status->name}} ({{$payment->status->description}}) </li>
                               
                            </ul>
  
                            @if($payment->status_id == 2)  
                            
                            @else  
                              <br/>                                                         
                                    @if($payment->type_id == 1)
                                        <a class="btn btn-success" id="process-payment" href="{{ route('payment-step2', $payment->uuid) }}">
                                        Continue with Payment
                                        </a>
                                    @else
                                        <a class="btn btn-success" id="process-payment" href="{{ route('payment-wallet', $payment->uuid) }}">
                                         Continue with Payment
                                        </a>
                                    @endif
                            @endif
                
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
        
                </div>
            </div>
        </div>    
    
    @endforeach