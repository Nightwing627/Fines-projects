 @extends('layouts.pdf') @section('content')

<div class="container">

    <div class="row transaction-spacer">

        <div class="col">

            @if($payment->status_id == 2)
            <div class="alert alert-success text-center text-uppercase" role="alert">
                <strong>{{$payment->status->name}}!</strong>
            </div>
            @else
            <div class="alert alert-warning text-center text-uppercase" role="alert">
                <strong>{{$payment->status->name}}!</strong>
            </div>
            @endif


        </div>


    </div>


    <div class="row transaction-spacer">

        <div class="col">

            <div class="client-address">
                <p class="doc-line">
                    <strong>{{ $customer->name }} </strong>
                </p>
                <p class="doc-line">Email: {{ $customer->email }} </p>
                <p class="doc-line"> Mobile: {{ $customer->mobile }} </p>
            </div>

        </div>



        <div class="col text-right">

            <p class="doc-line">
                <strong>Receipt #: PMT-00{{ $payment->id }} </strong>
            </p>
            <p class="doc-line">Date: {{ Carbon::parse($payment->created_date)->toFormattedDateString() }} </p>
            <p class="doc-line">ID Number: {{ $customer->id_number }} </p>
        </div>


    </div>


    <div class="row">

        <div class="col">

            <div class="table-responsive">
                <table class="table invoice-table">
                    <thead class="thead-light">
                        <tr>
                            <th>Notice #</th>
                            <th>Reg #</th>
                            <th>Municipality</th>
                            <th class="text-right">Total Payable</th>
                        </tr>
                    </thead>
                    <tbody>

                        @foreach($payment->fines as $fine)

                        <tr>
                            <td>{{$fine->fine->notice_number}}</td>
                            <td>{{$fine->fine->reg_number}}</td>
                            <td>{{$fine->fine->municipality}}</td>
                            <td class="text-right">R{{number_format($fine->fine->total_payable, 2, '.', ' ') }} </td>

                        </tr>

                        @endforeach

                    </tbody>
                </table>
            </div>

        </div>

    </div>




    <div class="row">

        <div class="col">

            <table class="table table-striped no-footer-padding" width="100%" border="0" cellspacing="0" cellpadding="0">

                <tr class="info">
                    <th scope="row">Total Payable </th>
                    <td class="text-right">
                        <strong>R{{number_format($payment->amount, 2, '.', ' ') }} </strong>
                    </td>
                </tr>
                <tr class="info">
                    @if($payment->status_id == 2)
                    <th scope="row">Total Paid </th>
                    <td class="text-right">
                        <strong>R{{number_format($payment->amount, 2, '.', ' ') }} </strong>
                    </td>
                    @else
                    @endif
                </tr>
            </table>

        </div>

    </div>



    <div class="col-sm-6">



    </div>

    <div class="clearfix"></div>


</div>


</div>
@endsection