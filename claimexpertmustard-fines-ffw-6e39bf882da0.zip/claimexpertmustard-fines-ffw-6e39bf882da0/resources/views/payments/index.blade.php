@extends('layouts.fines')

@section('header')
    @include('headers.payments')
@endsection


@section('content')
<div class="container">
    
        <div class="row justify-content-center">


                <div class="col-md-12 bottom-spacer">

                        <a class="btn btn-primary" href="{{ route('payment') }}" role="button">New Payment <i class="fas fa-long-arrow-alt-right"></i> </a>
                    
                </div>
        

                <div class="col-md-12">
                        
                    @include('payments.list')
    
                </div>
    
        </div>

    </div>
@endsection
