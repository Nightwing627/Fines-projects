@extends('layouts.fines') 

@section('header') 
    @include('headers.thanks') 
@endsection 

@section('content')

<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12 text-center">

            <p class="text-center font-weight-bold">Your Payment was successful:</p>
            
            <ul class="list-group list-group-flush">
                    <li class="list-group-item"><span>ID Number: </span>{{$payment->id_number}}</li>
                    <li class="list-group-item"><span>Payment Date: </span> {{ Carbon::parse($payment->created_at)->toFormattedDateString() }}</li>
                    <li class="list-group-item"><span>Reference: </span>{{$payment->reference}}</li>       
                    <li class="list-group-item"><span>Payment Amount: </span> R{{number_format($payment->amount, 2, '.', ' ') }}</li>

                   
                </ul>
                <br/>
                <br/>
            <a class="btn btn-success" target="_blank" href="/payment/receipt/{{$payment->uuid}}"> View Receipt </a>

            <br/>
            <br/>
            <br/>

            <a class="btn btn-primary btn-sm" target="_blank" href="/payments"> Back to Payments </a>
              
        </div>


    </div>
</div>
@endsection