@foreach($payment->fines as $fine) 

    <a data-toggle="modal" data-target="#fine-{{$fine->fine->id}}" href="#"> {{$fine->fine->notice_number}}   </a>
   
    <br/> 
    
@endforeach 



 @foreach($payment->fines as $fine)

<div class="modal fade" id="fine-{{$fine->fine->id}}" tabindex="-1" role="dialog" aria-labelledby="fine-{{$fine->fine->id}}" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        
            <div class="modal-header">
                <h5 class="modal-title" id="fine-{{$fine->fine->id}}Label">Fine Notice #: {{$fine->fine->notice_number}}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        
            <div class="modal-body">

                    <ul class="list-group list-group-flush">
                            {{-- <li class="list-group-item"><span>Notice: </span> {{$fine->fine->notice_number}}</li> --}}
                            <li class="list-group-item"><span>Reg #: </span> {{$fine->fine->reg_number}}</li>
                            <li class="list-group-item"><span>ID Number: </span>{{$fine->fine->id_number}}</li>
                            <li class="list-group-item"><span>Offence Date: </span> {{ Carbon::parse($fine->fine->offence_date)->toFormattedDateString() }}</li>
                            <li class="list-group-item"><span>Municipality: </span>{{$fine->fine->municipality}}</li>

                            <li class="list-group-item"><span>Fine Classification: </span>{{$fine->fine->fine_classification}}</li>
                            <li class="list-group-item"><span>Location: </span>{{$fine->fine->offence_location}}</li>
                            <li class="list-group-item"><span>Description: </span>{{$fine->fine->offence_description}}</li>
                             
                            <li class="list-group-item"><span>Issued Amount: </span> R{{number_format($fine->fine->issued_amount, 2, '.', ' ') }}</li>
                            <li class="list-group-item"><span>- Discounted Amount: </span> R{{number_format($fine->fine->discounted_amount, 2, '.', ' ') }}</li>
                            <li class="list-group-item"><span>+ Admin Fee: </span> R{{number_format($fine->fine->fe_admin_fee, 2, '.', ' ') }}</li>
                            <li class="list-group-item"><span>+ Discount Share: </span> R{{number_format($fine->fine->fe_discount_share, 2, '.', ' ') }}</li>
                            <li class="list-group-item"><span>= Total Payable: </span> R{{number_format($fine->fine->total_payable, 2, '.', ' ') }}</li>
                          </ul>

                 
        
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>

@endforeach 