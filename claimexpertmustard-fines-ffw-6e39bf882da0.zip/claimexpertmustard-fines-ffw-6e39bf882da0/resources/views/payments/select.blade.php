@extends('layouts.fines') 

@section('header') 
    @include('headers.payment') 
@endsection 

@section('content')

        <div class="container">

            <div class="row justify-content-center bottom-spacer">

                <div class="col-md-12">

                        {!! Form::model($payment,
                            ['method' => 'PATCH',
                            'name' => 'payment-selected',
                            'id' => 'payment-selected',
                            'route' => ['payment-selected', $payment->uuid],
                            'class' => 'form form-table',
                            ]) !!}
                            
                            <div class="form-group row">
                                    <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('How would you like to pay?') }}</label>
        
                                    <div class="col-md-6">
                                        
                                            {!! Form::select('type_id', App\Models\PaymentType::where('id','!=','3')->pluck('name','id')->toArray(),  null,
                                            [
                                            'class'                         => 'form-control',
                                            'placeholder'                   => 'Select a Payment Type',
                                            'required',
                                            'id'                            => 'type_id',
                                            ])
                                            !!}
        
                                    </div>
                            </div>

                            
                            <div class="form-group row mb-0">
                                    <div class="col-md-6 offset-md-4">
                                                {!! Form::submit('Proceed to Payment', ['value' => 'validate', 'class' => 'btn btn-primary']) !!}
                                    </div>
                                </div>
                       
        
                    {!! Form::close() !!}

                </div>
            </div>


        </div>


@endsection