@guest

@else

    @if($user->has_wallet) 

        <li class="nav-item"> 
                <a href="{{ route('wallet') }}" tabindex="0" class="btn nav-link" role="button" data-toggle="tooltip" title="Make easy payments using your Wallet"><i class="far fa-credit-card"></i> R{{$user->wallet_balance}}  </a>
        </li>

    @else
        
        <li class="nav-item"> 
                <a href="{{ route('wallet') }}" tabindex="0" class="btn nav-link" role="button" data-toggle="tooltip" title="Make easy payments using your Wallet"><i class="far fa-credit-card"></i> </a>
        </li>

    @endif

@endguest



