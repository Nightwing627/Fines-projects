@extends('layouts.fines')

@section('header')
    @include('headers.payment')
@endsection


@section('content')

<div class="container">
    
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
            
                <div class="card bg-light mb-3">
                   
                        <div class="card-body">
                          <h5 class="card-title">Select Fines to Pay</h5>
                          <p class="card-text"></p>
                          
                            {!! Form::open(
                                array(
                                    'method' => 'POST',
                                    'action' => 'PaymentsController@payment_store',
                                    'class' => 'form form-table'))
                            !!}
                    

                            {{-- {!! Form::hidden('tenderId', $tender->id); !!} --}}

                                <table id="" class="display-alt table table-bordered table-striped table-hover table-responsive" cellspacing="0" width="">

                                        <thead>

                                        <tr>
                                            <th> </th>
                                            <th>Notice # </th>
                                            <th>Amount</th>
                                            <th>Discount</th>
                                            <th>Admin Fee</th>
                                            <th>Payable</th>
                                            
                                        </tr>

                                        </thead>
                                        
                                        <tbody>

                                                @foreach($fines as $fine)

                                                        <tr>
                                                            <td>  <input type="checkbox" name="ids[]" data-id="checkbox" class="cb" value="{{$fine->id}}" />   </td>
                                                            <td> {{$fine->notice_number}} </td>
                                                            <td> R{{number_format($fine->issued_amount, 2, '.', ' ') }} </td>
                                                            <td> R{{number_format($fine->discounted_amount, 2, '.', ' ') }} </td>
                                                            <td> R{{number_format($fine->fe_admin_fee, 2, '.', ' ') }} </td>
                                                            <td> R{{number_format($fine->total_payable, 2, '.', ' ') }} </td>
                                                           
                                                        </tr>

                                                @endforeach

                                        </tbody>
                                </table>
                                                        
                            
                    
                                {!! Form::submit('Next', ['class' => 'btn btn-success']) !!}
                                            
                    
                            {!! Form::close() !!}

                        </div>
                      </div>
                      


        </div>

    </div>

</div>

@endsection
