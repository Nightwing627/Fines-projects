@component('mail::message')
# Welcome
<br/><br/>
Dear {{ $user->name }}
<br/><br/>
You have been pre-registered on our new easy to use self-service traffic fines assistance
website.<br/><br/>
On this website you will be able to see traffic fines that have been issued to you and you will also receive notification via email every time a new traffic fine is added to your profile.
<br/><br/>
You will also be able to use the convenient online payment facility to pay for your traffic fines and any discounts we negotiate on your behalf will be for your benefit.
<br/><br/>
Please click on the link below to log in with your email address and your South African ID number as password.
<br/><br/>

@component('mail::button', ['url' => 'https://ffw.finesupport.co.za'])
Login
@endcomponent

All the best <br/>
{{ config('app.name') }}
<br/><br/><br/><br/>
To unsubscribe from these emails and stop receiving fine notifications please click <a href="https://ffw.finesupport.co.za/profile">here</a>.
@endcomponent