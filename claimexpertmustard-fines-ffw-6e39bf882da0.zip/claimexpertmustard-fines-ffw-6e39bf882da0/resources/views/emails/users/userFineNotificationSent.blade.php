@component('mail::message')
# Fines Notitication
<br/><br/>
Dear {{ $name }}
<br/><br/>
We have identified {{ $count }} fine(s) linked to you. Please click on the link below to log into the First
for Women Fine Support website to view the fine details and your options.
<br/><br/>

@component('mail::button', ['url' => 'https://ffw.finesupport.co.za'])
Login
@endcomponent

All the best
{{ config('app.name') }}
<br/><br/><br/><br/>
To unsubscribe from these emails and stop receiving fine notifications please click <a href="https://ffw.finesupport.co.za/profile">here</a>.
@endcomponent