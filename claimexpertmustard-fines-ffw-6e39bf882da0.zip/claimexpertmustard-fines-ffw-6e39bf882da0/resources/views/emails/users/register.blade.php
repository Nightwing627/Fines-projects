@component('mail::message')
# New Registration

A new user has just registered on First for Women Fine Support:
<br/><br/>
Name: {{ $name }}  <br/>
Email: {{ $email }} <br/>
ID Number: {{ $id_number }} <br/>
Mobile Number: {{ $mobile }} <br/> <br/>

@component('mail::button', ['url' => 'https://ffw.finesupport.co.za'])
Maange Users
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
