@component('mail::message')
# Thank you

Thank you for your contact request. We will get back to you as soon as possible.

Name: {{ $first_name }} <br/>
Surname: {{ $last_name }} <br/>
Email: {{ $email }} <br/>
Phone: {{ $phone }} <br/>
Message: {{ $message }} <br/> <br/>

@component('mail::button', ['url' => 'https://ffw.finesupport.co.za'])
Check My Fines
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent

