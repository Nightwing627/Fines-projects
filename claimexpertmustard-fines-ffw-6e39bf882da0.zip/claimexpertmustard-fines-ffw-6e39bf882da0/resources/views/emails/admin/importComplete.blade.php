@component('mail::message')
# Import Complete

Your import is complete.<br/>

Ref: {{ $import_ref }} <br/>
Date: {{ $date }} <br/>
Records: {{ $records }} <br/> <br/>

@component('mail::button', ['url' => 'https://ffw.finesupport.co.za'])
Log in
@endcomponent

If you would like to send out client notifications, click the link below:

@component('mail::button', ['url' => 'https://ffw.finesupport.co.za/admin/import/notifications/send'])
Send Client Notifications
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent