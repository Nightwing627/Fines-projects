@component('mail::message')
# User Import Complete

Your user import is complete.<br/>

Ref: {{ $import_ref }} <br/>
Date: {{ $date }} <br/>
<br/>

@component('mail::button', ['url' => 'https://ffw.finesupport.co.za'])
Log in
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
