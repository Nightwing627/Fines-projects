<!-- Header -->
<header class="masthead">
  <div class="container">
    <div class="intro-text admin-header">
      <div class="intro-lead-in admin-lead-in">My Profile</div>
    </div>
  </div>
</header>