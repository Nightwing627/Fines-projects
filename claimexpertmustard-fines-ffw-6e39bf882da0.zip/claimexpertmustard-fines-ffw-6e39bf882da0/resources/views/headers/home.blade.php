<!-- Header -->
<header class="masthead">
  <div class="container">
    <div class="intro-text">
      <div class="intro-lead-in">Welcome to <span>1st for Women</span> <br/> Fine Support Fine Management Portal.</div>
    </div>
  </div>
</header>