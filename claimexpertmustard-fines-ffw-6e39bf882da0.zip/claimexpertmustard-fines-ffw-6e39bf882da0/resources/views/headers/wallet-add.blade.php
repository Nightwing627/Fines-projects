<!-- Header -->
<header class="masthead">
  <div class="container">
    <div class="intro-text admin-header">
      <div class="intro-lead-in admin-lead-in">Add Credit to your Wallet</div>
    </div>
  </div>
</header>