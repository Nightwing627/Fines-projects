<div class="container">

    <div class="row">

        <div class="col">

            <div class="pdf-logo">
                <img src="http://mustard.studio/fine/wp-content//themes/fine/images/logo.png" alt="Fine Expert">
            </div>

        </div>

        <div class="col text-right">

            <h1 class="doc-title">Pro Forma Invoice</h1>
            <p class="doc-line"><strong>Fine Expert</strong></p>
            <p class="doc-line">PO Box 61272</p>
            <p class="doc-line">Marshalltown</p>
            <p class="doc-line">Johannesburg, 2107</p>
        </div>

    </div>

</div>