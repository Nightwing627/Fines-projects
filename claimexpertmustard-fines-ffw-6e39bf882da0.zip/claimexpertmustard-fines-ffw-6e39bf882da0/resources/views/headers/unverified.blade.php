<!-- Header -->
<header class="masthead">
  <div class="container">
    <div class="intro-text admin-header">
      <div class="intro-lead-in admin-lead-in">Please Verify Your Account</div>
    </div>
  </div>
</header>