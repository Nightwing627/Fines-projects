<!-- Header -->
<header class="masthead">
  <div class="container">
    <div class="intro-text admin-header">
      <div class="intro-lead-in admin-lead-in">Make a Payment</div>
    </div>
  </div>
</header>