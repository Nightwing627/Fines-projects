@if($user->status_id == 1)  
    <a class="dropdown-item" id="admin-block-{{ $user->id }}" href="{{ route('admin-block', $user->id) }}">Block User </a>
@elseif($user->status_id == 2)   
    <a class="dropdown-item" id="admin-unblock-{{ $user->id }}" href="{{ route('admin-unblock', $user->id) }}">Unblock User </a>
@else
    <a class="dropdown-item" id="admin-unblock-{{ $user->id }}" href="{{ route('admin-approve', $user->id) }}">Approve User </a>
@endif