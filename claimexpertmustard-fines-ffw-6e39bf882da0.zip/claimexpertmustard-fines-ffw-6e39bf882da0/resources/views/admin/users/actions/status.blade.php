@if($user->role_id == 1)  
    <a class="dropdown-item" id="admin-downgrade-{{ $user->id }}" href="{{ route('admin-downgrade', $user->id) }}">Downgrade to Customer </a>
@else                           
    <a class="dropdown-item" id="admin-convert-{{ $user->id }}" href="{{ route('admin-convert', $user->id) }}">Convert to Admin User </a>
@endif