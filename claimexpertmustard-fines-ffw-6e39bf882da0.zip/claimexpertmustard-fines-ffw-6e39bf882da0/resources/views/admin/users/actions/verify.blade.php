@if($user->verified == 1)  
@else   
    <a class="dropdown-item" id="admin-reverify-{{ $user->id }}" href="{{ route('admin-resend-verify', $user->id) }}">Resend Verification Email </a>
@endif