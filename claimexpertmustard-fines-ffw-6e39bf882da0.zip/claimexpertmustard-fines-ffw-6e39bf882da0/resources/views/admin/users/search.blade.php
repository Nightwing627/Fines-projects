{!! Form::open(

    array(
         'url'    => 'admin/users/search/',
         'method' => 'GET',
         'class'  => 'form form-table',
         ))

!!}

<br/>

        <p>We found <strong>{{number_format($users->count(), 0, '.', ' ') }}</strong> users in the database.</p>

        <div class="row">

            <div class="col-md-12">



                <select name="user" id="userFullList" class=""> </select>

            </div>

        </div>

        
    {!! Form::button('<i class="fa fa-fw fa-search"></i> Search', array(
            'type' => 'submit',
            'class'=> 'btn btn-primary',
            ))
    !!}

 {!! Form::close() !!}


 <hr/>

 <p>Or Export the full list of users:</p>

 @include('admin.users.export')