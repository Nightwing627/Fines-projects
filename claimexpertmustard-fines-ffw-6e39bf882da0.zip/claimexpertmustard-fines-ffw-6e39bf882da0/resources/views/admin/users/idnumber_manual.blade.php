<!-- Modal -->
<div class="modal fade" id="addIDNumbersManual" tabindex="-1" role="dialog" aria-labelledby="addIDNumbersManualLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addIDNumbersManualLabel">Add New ID Number</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
            {!! Form::open(
                array(
                    'method' => 'POST',
                    'action' => 'IDListController@create',
                    'class' => 'form form-table'))
            !!}
    
            {!! Form::text('id_number', null, [
                'class'                         => 'form-control',
                'placeholder'                   => 'Enter an ID Number...',
                'required',
                'id'                            => 'id_number',
             ]) !!}


             <br/>
               
    
                {!! Form::submit('Add ID Number', ['class' => 'btn btn-success']) !!}
                            
    
            {!! Form::close() !!}



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>