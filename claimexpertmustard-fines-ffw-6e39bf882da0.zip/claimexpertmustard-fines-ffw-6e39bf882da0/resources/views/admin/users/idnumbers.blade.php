<div class="table-hold-tabs">


        <button type="button" class="btn btn-primary m-b-20" data-toggle="modal" data-target="#addIDNumbers">
                Import ID Numbers
        </button>
  
        <button type="button" class="btn btn-primary m-b-20" data-toggle="modal" data-target="#addIDNumbersManual">
                Add New ID Number
        </button>
  
        @include('admin.users.idnumbers_add')
        @include('admin.users.idnumber_manual')
    
 
        <table id="userIDList" class="table table-striped" cellspacing="0" width="100%">
    
          <thead>
              <tr>
                   
                   <th>ID Number </th>
                   <th> </th>
              </tr>
          </thead>
    
        <tbody>
    
            @foreach($idnumbers as $idnumber)
    
                <tr>
                    <td> {{$idnumber->id_number}} </td>
                    <td>  </td>
                </tr>
    
            @endforeach
    
        </tbody>
    
    </table>
    
</div>