<div class="table-hold">
 
    <table id="finesList" class="table table-striped" cellspacing="0" width="100%">

      <thead>
          <tr>
            <th>ID Number </th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Role</th>
            <th>Status</th>
            <th> </th>
            <th> </th>
          </tr>
      </thead>

      <tbody>
    
            <tr>
                <td> {{$user->id_number}} </td>
                <td> {{$user->first_name}} </td>
                <td> {{$user->last_name}} </td>
                <td> {{$user->email}} </td>
                <td> {{$user->mobile}} </td>

                <td> @if($user->role_id == 1) Admin @else Customer @endif </td>
                <td> @if($user->verified == 1) {{$user->status->name}} @else Unverified @endif </td>
              
                <td> <a data-toggle="modal" data-target="#user-{{$user->id}}" href="#"> <i class="fas fa-long-arrow-alt-right"></i></a>  </td>
                <td>  
                    <div class="btn-group" role="group">
                    <button id="btnGroupDrop1" type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Actions
                    </button>
                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                            @include('admin.users.actions.status')
                            @include('admin.users.actions.verify')
                            @include('admin.users.actions.block')
                     
                    </div>
                  </div>
                </td>

            </tr>

    </tbody>

</table>

</div>



<div class="modal fade" id="user-{{$user->id}}" tabindex="-1" role="dialog" aria-labelledby="user-{{$user->id}}" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        
            <div class="modal-header">
                <h5 class="modal-title" id="user-{{$user->id}}Label">User: {{$user->id_number}}</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
        
            <div class="modal-body">

                    <ul class="list-group list-group-flush">
                        <li class="list-group-item"><span>ID Number: </span>{{$user->id_number}}</li>
                        <li class="list-group-item"><span>Registered Date: </span> {{ Carbon::parse($user->created_at)->toFormattedDateString() }}</li>
                        <li class="list-group-item"><span>First Name: </span>{{$user->first_name}}</li> 
                        <li class="list-group-item"><span>Last Name: </span>{{$user->last_name}}</li> 
                        <li class="list-group-item"><span>Name: </span>{{$user->name}}</li> 
                        <li class="list-group-item"><span>Email: </span>{{$user->email}}</li>       
                        <li class="list-group-item"><span>Mobile: </span>{{$user->mobile}}</li>   
                        <li class="list-group-item"><span>Role: </span>@if($user->role_id == 1) Admin @else Customer @endif </li>   
                        <li class="list-group-item"><span>Status: </span> @if($user->verified == 1) {{$user->status->name}} @else Unverified @endif</li>       

                        <li class="list-group-item"><span>Wallet Balance: </span> @if($user->has_wallet == 1) R{{$user->wallet_balance}} @else Not Active @endif</li>       

                    </ul>

            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>

        </div>
    </div>
</div>
