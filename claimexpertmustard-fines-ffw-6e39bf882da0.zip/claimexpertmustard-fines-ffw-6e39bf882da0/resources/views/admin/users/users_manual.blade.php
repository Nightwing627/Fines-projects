<!-- Modal -->
<div class="modal fade" id="importUsers" tabindex="-1" role="dialog" aria-labelledby="addIDNumbersManualLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addIDNumbersManualLabel">Import Users</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

            <div class="alert alert-warning" role="alert">
                    Only valid csv files using the correct template will be processed. <a target="_blank" href="/sample_users.csv">Download a sample here </a>
                </div>
      
      
       
                {!! Form::open(
                    array(
                        'method' => 'POST',
                        'action' => 'UserController@importerNew',
                        'files' => 'true',
                        'class' => 'form form-table'))
                !!}
        
            
                    <div class="form-group">
                        <label for="exampleFormControlFile1">Select a file...</label>
                        {!! Form::file('file', ['class' => ' form-control-file', 'id' => 'fileImporter']) !!}
                    </div>
    
        
                    {!! Form::submit('Import Users', ['class' => 'btn btn-success']) !!}
                                
        
                {!! Form::close() !!}
    
    


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>