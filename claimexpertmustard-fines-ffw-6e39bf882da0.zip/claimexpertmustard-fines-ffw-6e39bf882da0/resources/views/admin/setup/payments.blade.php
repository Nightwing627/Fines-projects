<div class="table-hold-tabs">

        <button type="button" class="btn btn-primary m-b-20" data-toggle="modal" data-target="#addPaymentFine">
            Add Payment Status
        </button>

    
 
        <table id="fineStatusList" class="table table-striped" cellspacing="0" width="100%">
    
                <thead>
                    <tr>
                        <th>Status ID </th>
                        <th>Name</th>
                        <th> </th>
                    </tr>
                </thead>
    
                <tbody>
    
                    @foreach($paymentStatuses as $status)
    
                        <tr>
                            <td> {{$status->id}} </td>
                            <td> {{$status->name}} </td>
                            <td>   <a class="btn btn-primary btn-sml pull-right" id="delPmt-{{ $status->id }}" href="{{ route('admin-destroyPaymentStatus', $status->id) }}">Delete </a> </td>
                        </tr>
    
                    @endforeach
    
                </tbody>
    
        </table>
    
</div>
    



<!-- Modal -->
<div class="modal fade" id="addPaymentFine" tabindex="-1" role="dialog" aria-labelledby="addPaymentFineLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addPaymentFineLabel">Add a Payment Status</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            @include('admin.setup.payment-status-create')
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>