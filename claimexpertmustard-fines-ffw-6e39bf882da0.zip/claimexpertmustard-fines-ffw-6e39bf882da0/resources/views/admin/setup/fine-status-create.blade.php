<div class="col-md-12">


        {!! Form::open(
            ['method' => 'POST',
            'action' => 'AdminController@createFineStatus',
            'class'  => 'form form-table',
            'id'     => 'createFineStatus',
            'data-parsley-validate'
            ]
            )!!}
        

            <div class="form-group row">
                    <label for="name" class="col-md-2 col-form-label text-md-right">{{ __('Name') }}</label>

                    <div class="col-md-10">
                        
                            {!! Form::text('name', null, [
                                'class'                         => 'form-control',
                                'placeholder'                   => 'Enter a unique Fine Status name...',
                                'required',
                                'autofocus',
                                'id'                            => 'name',
                             ]) !!}

                    </div>
            </div>


            <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-2">
                        <button type="submit" class="btn btn-primary">
                                {!! Form::submit('Add Status', ['value' => 'validate', 'class' => 'btn btn-primary']) !!}
                        </button>
                    </div>
                </div>
       

            
        {!! Form::close() !!}
            

</div>