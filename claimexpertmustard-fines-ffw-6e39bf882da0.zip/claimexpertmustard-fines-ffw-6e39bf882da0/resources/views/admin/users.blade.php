@extends('layouts.admin')

@section('header')
    @include('headers.admin')
@endsection


@section('content')

<div class="container">
    
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            

                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                          <li class="nav-item">
                            <a class="nav-link active" id="fines-tab" data-toggle="tab" href="#fines" role="tab" aria-controls="fines" aria-selected="true">Users</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="payments-tab" data-toggle="tab" href="#payments" role="tab" aria-controls="payments" aria-selected="false">ID Numbers</a>
                          </li>
                        </ul>
                        
                        <!-- Tab panes -->
                        <div class="tab-content">
                          <div class="tab-pane active" id="fines" role="tabpanel" aria-labelledby="fines-tab">

                            <br/>

                            <button type="button" class="btn btn-primary m-b-20" data-toggle="modal" data-target="#importUsers">
                                Import Users
                            </button>
                      
                            @include('admin.users.users_manual')

                            @include('admin.users.search')

                            </div>
                          
                          <div class="tab-pane" id="payments" role="tabpanel" aria-labelledby="payments-tab">
                                @include('admin.users.idnumbers')
                          </div>
                          
                        </div>
            
           

        </div>

    </div>

</div>

@endsection
