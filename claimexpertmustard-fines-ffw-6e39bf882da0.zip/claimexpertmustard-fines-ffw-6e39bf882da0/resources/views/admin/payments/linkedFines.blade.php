@foreach($payment->fines as $fine) 

    {{--  <a data-toggle="modal" data-target="#fine-{{$fine->fine->id}}" href="#"> {{$fine->fine->notice_number}}   </a>  --}}
     {{$fine->fine->notice_number}} 
    <br/> 
    
@endforeach 