<div class="table-hold">
 
        <table id="paymentList" class="table table-striped" cellspacing="0" width="100%">
    
          <thead>
              <tr>
                   {{-- <th><i class="fas fa-paperclip"></i> </th> --}}
                   <th>Internal Ref </th>
                   <th>Payment Date</th>
                   <th>Amount</th>
                   <th>Linked Fine/s</th>
                   <th> </th>
    
                   
    
              </tr>
          </thead>
    
        <tbody>
    
            @foreach($payments as $payment)
    
                <tr>
                  {{-- <td> @if($fine->fine_doc) <a target="_blank" href="{{$fine->fine_doc}}"><i class="far fa-file-pdf"></i> </a> @else  @endif </td> --}}
                  <td> {{$payment->id}} </td>
                  <td> {{ Carbon::parse($payment->created_at)->toFormattedDateString() }} </td>
                  <td> R{{number_format($payment->amount, 2, '.', ' ') }} </td>
                  <td> @include('admin.payments.linkedFines') </td>
                  <td> <a data-toggle="modal" data-target="#pay-{{$payment->id}}" href="#"> <i class="fas fa-long-arrow-alt-right"></i></a>  </td>
                  
                </tr>
    
            @endforeach
    
        </tbody>
    
    </table>
    
    </div>
    
    
    @foreach($payments as $payment)
    
    
    <div class="modal fade" id="pay-{{$payment->id}}" tabindex="-1" role="dialog" aria-labelledby="pay-{{$payment->id}}" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                
                    <div class="modal-header">
                        <h5 class="modal-title" id="pay-{{$payment->id}}Label">Payment: {{$payment->id}}</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                
                    <div class="modal-body">
        
                        <ul class="list-group list-group-flush">
                            {{--  <li class="list-group-item"><span>Payment #: </span> {{$payment->id}}</li>  --}}
                            <li class="list-group-item"><span>ID Number: </span>{{$payment->id_number}}</li>
                            <li class="list-group-item"><span>Payment Date: </span> {{ Carbon::parse($payment->created_at)->toFormattedDateString() }}</li>
                            <li class="list-group-item"><span>Remark: </span>{{$payment->remark}}</li> 
                            <li class="list-group-item"><span>Reference: </span>{{$payment->reference}}</li>       
                            <li class="list-group-item"><span>Payment Amount: </span> R{{number_format($payment->amount, 2, '.', ' ') }}</li>
                            <li class="list-group-item"><span>Payment Status: </span> @if($payment->status_id == 2) Approved @else Pending @endif </li>
                           
                        </ul>

                
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
        
                </div>
            </div>
        </div>    
    
    @endforeach