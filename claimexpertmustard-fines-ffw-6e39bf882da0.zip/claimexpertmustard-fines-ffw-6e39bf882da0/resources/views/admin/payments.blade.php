@extends('layouts.admin')

@section('header')
    @include('headers.admin')
@endsection


@section('content')

<div class="container">
    
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
            @include('admin.payments.list')

        </div>

    </div>

</div>

@endsection
