<div class="table-hold">
 
        <table id="importList" class="table table-striped" cellspacing="0" width="100%">
    
          <thead>
              <tr>
                   
                   <th>Ref</th>
                   <th>Fines</th>
                   <th>Date Added</th>
                   <th>Original File</th>
                   <th>Imported By</th>
                   {{--  <th>Undo </th>  --}}
              </tr>
          </thead>
    
        <tbody>
    
            @foreach($imports as $import)
    
                <tr>
                    <td> {{$import->import_ref}} </td>
                    <td> {{$import->records}} </td>
                    <td> {{$import->created_at}} </td>
                    <td> <a target="_blank" href="/{{ $import->file }}"><i class="far fa-file-excel"></i> Download <a/> </td>
                    <td> {{$import->creator->name}} </td>
                  
                    {{--  <td> @if($import->undone == 0)
                            @include('admin.imports.undo') 
                         @else 
                         Removed
                         @endif
                    </td>  --}}
                  
                </tr>
    
            @endforeach
    
        </tbody>
    
    </table>
    
    </div>