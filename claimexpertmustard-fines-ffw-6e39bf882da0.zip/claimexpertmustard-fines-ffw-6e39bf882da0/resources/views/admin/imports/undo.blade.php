
<a class="" id="undo-import-{{ $import->id }}" href="{{ route('admin-import-undo', $import->id) }}">
    <i class="fas fa-undo"></i>
</a>

        
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript">
    $(document).on('click', '#undo-import-{{ $import->id }}', function(e) {
        e.preventDefault();
        var link = $(this);
        swal({
            title: "Undo Import",
            text: "Do you Wish to Undo this Import & Remove the Related Fines?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Undo Import",
            closeOnConfirm: false
            },
            function(isConfirm){
                if(isConfirm){
                window.location = link.attr('href');
                }
                else{
                swal("cancelled","Action Cancelled", "error");
                }
            });
    });
</script>