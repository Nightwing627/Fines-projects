<div class="table-hold-tabs">

        <table id="fineStatusList" class="table table-striped" cellspacing="0" width="100%">
    
                <thead>
                        <tr>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Date Used</th>
                            <th>Linked Payment </th>
                            <th>Payment Ref </th>
                        </tr>
                    </thead>
        
                    <tbody>
        
                        @foreach($debits as $debit)  
        
                             <tr>
                                <td> {{$debit->customer->name}} </td>
                                <td> R{{number_format($debit->amount, 2, '.', ' ') }} </td>
                                <td> {{ Carbon::parse($debit->created_at)->toFormattedDateString() }} </td>
                                <td> {{$debit->payment_id}} </td>
                                <td> {{$debit->comment}} </td>
                            </tr> 
        
                        @endforeach
        
                    </tbody>
        
    
        </table>
    
    </div>
    