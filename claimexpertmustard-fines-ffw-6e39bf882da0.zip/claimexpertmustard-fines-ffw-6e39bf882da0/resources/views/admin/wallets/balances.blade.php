<div class="table-hold-tabs">

       
        <button type="button" class="btn btn-primary m-b-20" data-toggle="modal" data-target="#walletImport">
               Bulk Import Wallet Balances
        </button>
  
        @include('admin.wallets.manual-import')
    
 
    <table id="userBalanceList" class="table table-striped" cellspacing="0" width="100%">

            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Wallet Balance</th>
                   
                </tr>
            </thead>

            <tbody>

                @foreach($users as $user)  

                     <tr>
                        <td> {{$user->name}} </td>
                     
                        <td> R{{number_format($user->wallet_balance, 2, '.', ' ') }} </td>
                       
                    </tr> 

                @endforeach

            </tbody>

    </table>

</div>