<!-- Modal -->
<div class="modal fade" id="walletTopUp" tabindex="-1" role="dialog" aria-labelledby="walletTopUpLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="walletTopUpLabel">Manually Add Credit to Wallet</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
            {!! Form::open(
                ['method' => 'POST',
                'action' => 'AdminController@add_credit',
                'class'  => 'form form-table',
                'id'     => 'add_credit',
                ]
                )!!}
            


            <select name="user_id" id="customerList" class=""> </select>

            {!! Form::text('amount', null, [
                'class'                         => 'form-control',
                'placeholder'                   => 'Enter an amount...',
                'required',
                'id'                            => 'amount',
             ]) !!}


             <br/>

             <button type="submit" class="btn btn-sm btn-primary">
                    {!! Form::submit('Add Credit', ['value' => 'validate', 'class' => 'btn btn-primary']) !!}
            </button>

            
        {!! Form::close() !!}
            




      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>