<div class="table-hold-tabs">

       
        <button type="button" class="btn btn-primary m-b-20" data-toggle="modal" data-target="#walletTopUp">
                Manually Load Credit
        </button>
  
        @include('admin.wallets.manual-add')
    
 
    <table id="fineStatusList" class="table table-striped" cellspacing="0" width="100%">

            <thead>
                <tr>
                    <th>Purchase Date</th>
                    <th>Customer</th>
                    <th>Amount</th>
                    {{-- <th>Ref </th> --}}
                    <th>Status  </th>
                    <th>Receipt </th>
                </tr>
            </thead>

            <tbody>

                @foreach($credits as $credit)  

                     <tr>
                        <td> {{ Carbon::parse($credit->created_at)->toFormattedDateString() }} </td>
                        <td> {{$credit->customer->name}} </td>
                        <td> R{{number_format($credit->amount, 2, '.', ' ') }} </td>
                        {{-- <td> {{$credit->comment}}</td> --}}
                        <td> {{$credit->status->name}}</td>
                        <td> <a target="_blank" href="/wallet/receipt/{{$credit->uuid}}"> <i class="fas fa-print"></i> </a> </td>
                 
                    </tr> 

                @endforeach

            </tbody>

    </table>

</div>
