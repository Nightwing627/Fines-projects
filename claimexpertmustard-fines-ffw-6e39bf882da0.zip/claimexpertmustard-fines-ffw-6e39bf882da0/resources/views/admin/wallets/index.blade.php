@extends('layouts.admin')

@section('header')
    @include('headers.admin')
@endsection


@section('content')

<div class="container">
    
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="balances-tab" data-toggle="tab" href="#balances" role="tab" aria-controls="balances" aria-selected="false">Wallet Balances</a>
                  </li>
                  
              <li class="nav-item">
                <a class="nav-link" id="fines-tab" data-toggle="tab" href="#fines" role="tab" aria-controls="fines" aria-selected="true">Credits</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="payments-tab" data-toggle="tab" href="#payments" role="tab" aria-controls="payments" aria-selected="false">Debits</a>
              </li>
              
            </ul>
            
            <!-- Tab panes -->
            <div class="tab-content">
              
                <div class="tab-pane active" id="balances" role="tabpanel" aria-labelledby="balances-tab">

                   @include('admin.wallets.balances')

                </div>
              
              <div class="tab-pane" id="fines" role="tabpanel" aria-labelledby="fines-tab">
                @include('admin.wallets.credits')
              </div>
              
              <div class="tab-pane" id="payments" role="tabpanel" aria-labelledby="payments-tab">
                    @include('admin.wallets.debits')
              </div>
               
               
             
            </div>

        </div>

    </div>

</div>

@endsection
