{!! Form::open(

    array(
         'url'    => 'admin/fines/search/',
         'method' => 'GET',
         'class'  => 'form form-table',
         ))

!!}

        <p>We found <strong>{{number_format($fines->count(), 0, '.', ' ') }}</strong> fines in the database.</p>


    <div class="row">

        <div class="col-md-5">

            <select  name="fine" id="finesSearch" class=""> </select>

        </div>

        <div class="col-md-2 text-center">

            or

        </div>

        <div class="col-md-5">

            <select  name="id_number" id="idSearch" class=""> </select>

        </div>
        


    </div>


        

        {!! Form::button('<i class="fa fa-fw fa-search"></i> Search', array(
                'type' => 'submit',
                'class'=> 'btn btn-primary',
                ))
        !!}

 {!! Form::close() !!}