<div class="table-hold">
 
        <table id="fineList" class="table table-striped" cellspacing="0" width="100%">
    
          <thead>
              <tr>
                   <th><i class="fas fa-paperclip"></i> </th>
                   <th>Notice # </th>
                   {{-- <th>Reg No.</th> --}}
                   <th>Date</th>
                   <th>Linked ID #</th>
                   <th>Amount</th>
                   <th>Discount</th>
                   <th>Admin Fee</th>
                   <th>Payable</th>
                   <th>Status</th>
                   
                   <th> </th>
    
                   
    
              </tr>
          </thead>
    
        <tbody>
    
            @foreach($fines as $fine)
    
                <tr>
                  <td> @if($fine->fine_doc) <a target="_blank" href="{{$fine->fine_doc}}"><i class="far fa-file-pdf"></i> </a> @else  @endif </td>
                  <td> {{$fine->notice_number}} </td>
                  {{-- <td> {{$fine->reg_number}} </td> --}}
                  <td> {{ Carbon::parse($fine->offence_date)->toFormattedDateString() }} </td>
                  <td> {{$fine->id_number}} </td>
                  <td> R{{number_format($fine->issued_amount, 2, '.', ' ') }} </td>
                  <td> R{{number_format($fine->discount, 2, '.', ' ') }} </td>
                  <td> R{{number_format($fine->fe_admin_fee, 2, '.', ' ') }} </td>
                  <td> R{{number_format($fine->total_payable, 2, '.', ' ') }} </td>
                  <td> @if($fine->paid == 1) Paid @else Unpaid @endif </td>
                  
                  <td> <a data-toggle="modal" data-target="#view-{{$fine->id}}" href="#"> <i class="fas fa-long-arrow-alt-right"></i></a>  </td>
                  
                </tr>
    
            @endforeach
    
        </tbody>
    
    </table>
    
    </div>
    
    
    @foreach($fines as $fine)
    
    <div class="modal fade" id="view-{{$fine->id}}" tabindex="-1" role="dialog" aria-labelledby="view-{{$fine->id}}" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            
                <div class="modal-header">
                    <h5 class="modal-title" id="view-{{$fine->id}}Label">Fine Notice #: {{$fine->notice_number}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            
                <div class="modal-body">
    
                        <ul class="list-group list-group-flush">
                                {{-- <li class="list-group-item"><span>Notice: </span> {{$fine->notice_number}}</li> --}}
                                <li class="list-group-item"><span>Reg #: </span> {{$fine->reg_number}}</li>
                                <li class="list-group-item"><span>ID Number: </span>{{$fine->id_number}}</li>
                                <li class="list-group-item"><span>Offence Date: </span> {{ Carbon::parse($fine->offence_date)->toFormattedDateString() }}</li>
                                <li class="list-group-item"><span>Municipality: </span>{{$fine->municipality}}</li>
    
                                <li class="list-group-item"><span>Fine Classification: </span>{{$fine->fine_classification}}</li>
                                <li class="list-group-item"><span>Location: </span>{{$fine->offence_location}}</li>
                                <li class="list-group-item"><span>Description: </span>{{$fine->offence_description}}</li>
                                 
                                <li class="list-group-item"><span>Issued Amount: </span> R{{number_format($fine->issued_amount, 2, '.', ' ') }}</li>
                                <li class="list-group-item"><span>- Discounted: </span> R{{number_format($fine->discount, 2, '.', ' ') }}</li>
                                <li class="list-group-item"><span>Discounted Amount: </span> R{{number_format($fine->discounted_amount, 2, '.', ' ') }}</li>
                                <li class="list-group-item"><span>+ Admin Fee: </span> R{{number_format($fine->fe_admin_fee, 2, '.', ' ') }}</li>
                                <li class="list-group-item"><span>+ Discount Share: </span> R{{number_format($fine->fe_discount_share, 2, '.', ' ') }}</li>
                                <li class="list-group-item"><span>= Total Payable: </span> R{{number_format($fine->total_payable, 2, '.', ' ') }}</li>
                              </ul>
    
            
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
    
            </div>
        </div>
    </div>
    
    @endforeach