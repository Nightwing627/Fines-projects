@extends('layouts.admin')

@section('header')
    @include('headers.admin')
@endsection


@section('content')

<div class="container">
    
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">


@if($type == 1)

<div class="search-result-box">

        <h2> Search result for: {{$query}} </h2>
        <h4>We found <span>1 fine </span> matching your search </h4>

</div>

            @include('admin.fines.results.fine')

@endif



@if($type == 2)

<div class="search-result-box">

        <h2> Search result for: {{$query}} </h2>
        <h4>We found <span>{{$fines->count()}} fines</span> matching your ID Number search</h4>

</div>
           
            @include('admin.fines.results.fines')

@endif


@if($type == 3)


<div class="search-result-box">

        <h2> Search result for: {{$query}} </h2>
        <h4>We found <span>1 fine </span> matching your search </h4>

</div>



@include('admin.fines.results.fine')


<div class="search-result-box-alt">

        <h4>We found <span>{{$fines->count()}} fines</span> matching your ID Number search </h4>

</div>


@include('admin.fines.results.fines')

@endif

        </div>

    </div>

</div>

@endsection
