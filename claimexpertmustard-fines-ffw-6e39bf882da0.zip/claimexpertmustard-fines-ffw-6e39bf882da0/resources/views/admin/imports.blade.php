@extends('layouts.admin')

@section('header')
    @include('headers.admin')
@endsection


@section('content')

<div class="container">
    



        <div class="col-md-12 bottom-spacer">

                <a class="btn btn-primary pull-right" href="{{ route('admin-import') }}" role="button">Import New Fines <i class="fas fa-long-arrow-alt-right"></i> </a>
            
                <a class="btn btn-primary pull-right" href="{{ route('admin-import-notify') }}" role="button">Send Fine Notifications <i class="fas fa-long-arrow-alt-right"></i> </a>
            

        </div>




        <div class="col-md-12">

            @include('admin.imports.list')

        </div>

    </div>

</div>

@endsection
