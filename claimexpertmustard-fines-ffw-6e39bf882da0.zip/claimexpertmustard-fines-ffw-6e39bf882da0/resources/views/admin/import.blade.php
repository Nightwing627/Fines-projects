@extends('layouts.admin')

@section('header')
    @include('headers.admin')
@endsection


@section('content')
<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
           

                <div class="alert alert-warning" role="alert">
                    Only valid csv files using the correct template will be processed. <a target="_blank" href="/sample_data.csv">Download a sample here </a>
                </div>




                <div class="card bg-light mb-3">
                   
                        <div class="card-body">
                          <h5 class="card-title">File Importer</h5>
                          <p class="card-text"></p>
                          
                            {!! Form::open(
                                array(
                                    'method' => 'POST',
                                    'action' => 'ImportController@importer',
                                    'files' => 'true',
                                    'class' => 'form form-table'))
                            !!}
                    
                        
                                <div class="form-group">
                                    <label for="exampleFormControlFile1">Select a file...</label>
                                    {!! Form::file('file', ['class' => ' form-control-file', 'id' => 'fileImporter']) !!}
                                </div>

                    
                                {!! Form::submit('Import Fines', ['class' => 'btn btn-success']) !!}
                                            
                    
                            {!! Form::close() !!}

                        </div>
                      </div>
                      

        </div>

    </div>

    </div>
</div>
@endsection
