@extends('layouts.admin')

@section('header')
    @include('headers.admin')
@endsection


@section('content')
<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
           

            <div class="jumbotron">
                <h4>Welcome {{ $user->name }}</h4>
                <p class="lead">This is the administrative dashboard for <strong>1st For Women Fines</strong> Portal Powered by Fine Experts. Manage fines, imports and users with ease.</p>
                <hr class="my-4">
                <a class="btn btn-primary btn-lg" href="{{ route('admin-import') }}" role="button">Import New Fines <i class="fas fa-long-arrow-alt-right"></i> </a>
            </div>
             

        </div>

    </div>

    </div>
</div>
@endsection
