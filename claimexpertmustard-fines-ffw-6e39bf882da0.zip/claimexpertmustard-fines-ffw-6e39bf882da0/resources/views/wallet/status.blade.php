
@if($user->has_wallet) 

<p>Your Wallet Balance: <strong>R{{$user->wallet_balance}}</strong></p>

<a class="btn btn-success" id="walllet-purchase" href="{{ route('wallet-purchase') }}">
       Add Credit
    </a>

<br/>
<br/>
<br/>
<br/>


<a class="btn btn-danger btn-sm" id="walllet-{{ $user->id }}" href="{{ route('wallet-deactivate', $user->id) }}">
        Deactivate my Wallet
</a>


@else

    <h5 class="card-title">You Do Not have a Wallet yet </h5>
    <p class="card-text">You can use your wallet to make payments for your fines!</p>
    

    <a class="btn btn-primary" id="walllet-{{ $user->id }}" href="{{ route('wallet-activate', $user->id) }}">
        Activate my Wallet
    </a>

 @endif