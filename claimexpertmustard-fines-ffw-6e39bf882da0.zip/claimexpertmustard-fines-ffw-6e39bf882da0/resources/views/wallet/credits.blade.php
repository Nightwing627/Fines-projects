<div class="table-hold-tabs">

        @if($user->has_wallet) 
          
        <a class="btn btn-primary m-b-20" id="changePmtType" href="{{ route('wallet-purchase') }}">
                Buy More Credit
        </a>
    
        @else
        @endif
 
    <table id="fineStatusList" class="table table-striped" cellspacing="0" width="100%">

            <thead>
                <tr>
                    <th>Amount</th>
                    <th>Purchase Date</th>
                    <th>Purchase Ref </th>
                    <th>Status  </th>
                    <th>Receipt </th>
                </tr>
            </thead>

            <tbody>

                @foreach($credits as $credit)  

                     <tr>
                        <td> R{{number_format($credit->amount, 2, '.', ' ') }} </td>
                        <td> {{ Carbon::parse($credit->created_at)->toFormattedDateString() }} </td>
                        <td> {{$credit->comment}}</td>
                        <td> {{$credit->status->name}}</td>
                        <td> <a target="_blank" href="/wallet/receipt/{{$credit->uuid}}"> <i class="fas fa-print"></i> </a> </td>
                 
                    </tr> 

                @endforeach

            </tbody>

    </table>

</div>
