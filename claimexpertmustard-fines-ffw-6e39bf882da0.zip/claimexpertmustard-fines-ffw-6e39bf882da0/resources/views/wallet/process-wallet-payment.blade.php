<p>Congratulations! You have enough credit available to process this transaction.</p>

<a class="btn btn-success" id="makeWalletPayment" href="{{ route('wallet-process-payment', $payment->uuid) }}">
       Use My Credit to Complete this Payment
</a>