@extends('layouts.fines')

@section('header')
    @include('headers.wallet')
@endsection


@section('content')
<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
                    
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item">
                <a class="nav-link active" id="overview-tab" data-toggle="tab" href="#overview" role="tab" aria-controls="overview" aria-selected="true">Overview</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" id="purchases-tab" data-toggle="tab" href="#purchases" role="tab" aria-controls="purchases" aria-selected="false">Purchases</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" id="payments-tab" data-toggle="tab" href="#payments" role="tab" aria-controls="payments" aria-selected="false">Payments</a>
                </li>
                
            </ul>
            
            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
                
                    <div class="card-body text-center">
                       @include('wallet.status')
                    </div>

                </div>
                
                <div class="tab-pane" id="purchases" role="tabpanel" aria-labelledby="purchases-tab">
                    @include('wallet.credits')
                </div>
                
                <div class="tab-pane" id="payments" role="tabpanel" aria-labelledby="payments-tab">
                    @include('wallet.payments')
                </div>
            
            </div>

             
    </div>


    </div>
</div>
@endsection
