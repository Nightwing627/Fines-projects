@extends('layouts.fines') @section('header') @include('headers.wallet-add') @endsection @section('content')

<div class="container">
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">


                {!! Form::open(
                    ['method' => 'POST',
                    'action' => 'WalletController@purchase_create',
                    'class'  => 'form form-table',
                    'id'     => 'purchase_create',
                    ]
                    )!!}
                
                    
                    <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('How much credit do you want to purchase?') }}</label>

                            <div class="col-md-6">
                                
                                {!! Form::text('amount', null, [
                                'class'                         => 'form-control',
                                'placeholder'                   => 'Enter a credit amount...',
                                'required',
                                'autofocus',
                                'id'                            => 'amount',
                             ]) !!}


                            </div>
                    </div>

                    
                    <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                     
                                        {!! Form::submit('Next', ['value' => 'validate', 'class' => 'btn btn-primary']) !!}
                        
                            </div>
                        </div>
               

            {!! Form::close() !!}



        </div>


    </div>
</div>
@endsection