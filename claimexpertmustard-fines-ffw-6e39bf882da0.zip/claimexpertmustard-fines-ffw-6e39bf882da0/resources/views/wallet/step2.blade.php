@extends('layouts.fines')

@section('header')
    @include('headers.wallet-add')
@endsection


@section('content')


<div class="container">
    
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
            
                <div class="card bg-light mb-3">
                   
                        <div class="card-body">
                          
                            <h5 class="card-title">Proceed to Payment</h5>
                            <p class="card-text">
                                You have selected to make a payment of <strong>R{{ $payment->amount }}.</strong>
                            </p>
                            
                            <form role="form" class="form-horizontal text-left" action="{{$url}}" method="post" name="paygate_process_form">

                            @foreach($responseData as $key => $value)
                               
                                <input type="hidden" name={{$key}} value={{$value}} />

                           @endforeach


                            {!! Form::submit('Redirect to Payment Gateway', ['value' => 'validate', 'class' => 'btn btn-success']) !!}


                        </div>
                
                </div>
                
        </div>

    </div>

</div>

@endsection
