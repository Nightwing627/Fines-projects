@extends('layouts.fines')

@section('header')
    @include('headers.fines')
@endsection


@section('content')

<div class="container">
    
    <div class="row justify-content-center bottom-spacer">

        <div class="col-md-12">
            
            @include('fines.list')

        </div>

    </div>

</div>

@endsection
