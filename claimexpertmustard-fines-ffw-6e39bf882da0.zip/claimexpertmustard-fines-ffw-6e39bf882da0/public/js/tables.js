$(document).ready(function() {
    $('#fineList').DataTable( {
        "paging":       true,
        "ordering":     true,
        "info":         true,
        "fixedHeader":  true,
        "responsive":   true,
        "dom":          'Bfrtip',
        "buttons": [
                    'copy', 'excel', 'pdf'
                 ],
        "oLanguage": {
                        "sEmptyTable" : 'We cannot find any fines linked to your ID Number.',
                        "zeroRecords" : 'No fines found matching that search query.',
                     }
    } );
} );


$(document).ready(function() {
    $('#paymentList').DataTable( {
        "paging":       true,
        "ordering":     true,
        "info":         true,
        "fixedHeader":  true,
        "responsive":   true,
        "dom":          'Bfrtip',
        "buttons": [
                    'copy', 'excel', 'pdf'
                 ],
        "oLanguage": {
                        "sEmptyTable" : 'We cannot find any payments made against your ID Number.',
                    }
    } );
} );


$(document).ready(function() {
    $('#userList').DataTable( {
        "paging":       true,
        "ordering":     true,
        "info":         true,
        "fixedHeader":  true,
        "responsive":   true,
        "dom":          'Bfrtip',
        "buttons": [
                    'copy', 'excel', 'pdf'
                 ],
        "oLanguage": {
                        "sEmptyTable" : 'No registered users found.',
                        "zeroRecords" : 'No users found matching that search query.',
                     }
    } );
} );


$(document).ready(function() {
    $('#importList').DataTable( {
        "paging":       true,
        "ordering":     true,
        "info":         true,
        "fixedHeader":  true,
        "responsive":   true,
        "oLanguage": {
                        "sEmptyTable" : 'No imports found.',
                        "zeroRecords" : 'No imports found matching that search query.',
                     }
    } );
} );


$(document).ready(function() {
    $('#userIDList').DataTable( {
        "paging":       true,
        "ordering":     true,
        "info":         true,
        "fixedHeader":  true,
        "responsive":   true,
        "dom":          'Bfrtip',
        "buttons": [
                    'copy', 'excel', 'pdf'
                 ],
        "oLanguage": {
                        "sEmptyTable" : 'No ID Numbers found.',
                        "zeroRecords" : 'No ID Numbers matching that search query.',
                     }
    } );
} );
