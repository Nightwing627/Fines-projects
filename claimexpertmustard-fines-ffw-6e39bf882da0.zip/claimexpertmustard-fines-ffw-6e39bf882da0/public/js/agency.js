(function($) {
  "use strict"; // Start of use strict

  // Smooth scrolling using jQuery easing
  $('a.js-scroll-trigger[href*="#"]:not([href="#"])').click(function() {
    if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
      if (target.length) {
        $('html, body').animate({
          scrollTop: (target.offset().top - 54)
        }, 1000, "easeInOutExpo");
        return false;
      }
    }
  });

  // Closes responsive menu when a scroll trigger link is clicked
  $('.js-scroll-trigger').click(function() {
    $('.navbar-collapse').collapse('hide');
  });

  // Activate scrollspy to add active class to navbar items on scroll
  $('body').scrollspy({
    target: '#mainNav',
    offset: 56
  });

  // Collapse Navbar
  var navbarCollapse = function() {
    if ($("#mainNav").offset().top > 100) {
      $("#mainNav").addClass("navbar-shrink");
    } else {
      $("#mainNav").removeClass("navbar-shrink");
    }
  };
  // Collapse now if page is not at top
  navbarCollapse();
  // Collapse the navbar when page is scrolled
  $(window).scroll(navbarCollapse);

  // Hide navbar when modals trigger
  $('.portfolio-modal').on('show.bs.modal', function(e) {
    $(".navbar").addClass("d-none");
  })
  $('.portfolio-modal').on('hidden.bs.modal', function(e) {
    $(".navbar").removeClass("d-none");
  })

})(jQuery); // End of use strict


// preload
$(document).ready(function() {
  $(function () {
    $('[data-toggle="tooltip"]').tooltip()
  })
});


$('#customerList').selectize({
  preload: true,
  persist: false,
  create: false,
  placeholder: "Select a customer...",
  valueField: 'id',
  labelField: 'name',
  searchField: ['name', 'id_number', 'email'],
  options: [],
  render: {
      item: function(item, escape) {
          return '<div>' +
          (item.name ? '<span>' + escape(item.name) + '</span>' : '') +
          (item.id_number ? '<span class="select-hidden">' + escape(item.id_number) + '</span>' : '') +
          (item.email ? '<span class="select-hidden">' + escape(item.email) + '</span>' : '') +
          '</div>';
      },
      option: function(item, escape) {
          var label = item.name || item.id_number;
          var id_number = item.id_number ? item.id_number : null;
          var email = item.email ? item.email : null;
          return '<div class="select-holder">' +
          '<span class="select-label">' + escape(label) + '</span>' +
          (id_number ? '<span class="select-caption">ID Number: ' + escape(id_number) + '</span>' : '') +
          (email ? '<span class="select-caption">Email: ' + escape(email) + '</span>' : '') +
          '</div>';
      }
  },
  load: function(query, callback) {
      //if (!query.length) return callback();
      $.ajax({
          url: '/api/data/customers',
          type: 'GET',
          dataType: 'json',
          data: {
              name: query
          },
          error: function() {
              callback();
          },
          success: function(res) {
              callback(res);
          }
      });
  }
});


$('#finesSearch').selectize({
  preload: false,
  persist: false,
  create: false,
  placeholder: "Search for a fine...",
  valueField: 'id',
  labelField: 'notice_number',
  searchField: ['notice_number', 'id_number', 'reg_number'],
  options: [],
  render: {
      item: function(item, escape) {
          return '<div>' +
          (item.notice_number ? '<span>' + escape(item.notice_number) + '</span>' : '') +
          (item.id_number ? '<span class="select-hidden">' + escape(item.id_number) + '</span>' : '') +
          (item.reg_number ? '<span class="select-hidden">' + escape(item.reg_number) + '</span>' : '') +
          '</div>';
      },
      option: function(item, escape) {
          var notice_number = item.notice_number || item.notice_number;
          var id_number = item.id_number ? item.id_number : null;
          var reg_number = item.reg_number ? item.reg_number : null;
          return '<div class="select-holder">' +
          '<span class="select-label">' + escape(notice_number) + '</span>' +
          (id_number ? '<span class="select-caption">ID Number: ' + escape(id_number) + '</span>' : '') +
          (reg_number ? '<span class="select-caption">Reg Number: ' + escape(reg_number) + '</span>' : '') +
          '</div>';
      }
  },
  load: function(query, callback) {
      //if (!query.length) return callback();
      $.ajax({
          url: '/api/data/fines',
          type: 'GET',
          dataType: 'json',
          data: {
              name: query
          },
          error: function() {
              callback();
          },
          success: function(res) {
              callback(res);
          }
      });
  }
});


$('#idSearch').selectize({
  preload: false,
  persist: false,
  create: false,
  placeholder: "Search for an ID Number...",
  valueField: 'id_number',
  labelField: 'id_number',
  searchField: ['id_number'],
  options: [],
  render: {
      item: function(item, escape) {
          return '<div>' +
          (item.id_number ? '<span>' + escape(item.id_number) + '</span>' : '') +
          '</div>';
      },
      option: function(item, escape) {
         
          var id_number = item.id_number ? item.id_number : null;
        
          return '<div class="select-holder">' +
          '<span class="select-label">' + escape(id_number) + '</span>' +
          '</div>';
      }
  },
  load: function(query, callback) {
      //if (!query.length) return callback();
      $.ajax({
          url: '/api/data/fines',
          type: 'GET',
          dataType: 'json',
          data: {
              name: query
          },
          error: function() {
              callback();
          },
          success: function(res) {
              callback(res);
          }
      });
  }
});


$('#userFullList').selectize({
    preload: true,
    persist: false,
    create: false,
    placeholder: "Select a user...",
    valueField: 'id',
    labelField: 'name',
    searchField: ['name', 'id_number', 'email'],
    options: [],
    render: {
        item: function(item, escape) {
            return '<div>' +
            (item.name ? '<span>' + escape(item.name) + '</span>' : '') +
            (item.id_number ? '<span class="select-hidden">' + escape(item.id_number) + '</span>' : '') +
            (item.email ? '<span class="select-hidden">' + escape(item.email) + '</span>' : '') +
            '</div>';
        },
        option: function(item, escape) {
            var label = item.name || item.id_number;
            var id_number = item.id_number ? item.id_number : null;
            var email = item.email ? item.email : null;
            return '<div class="select-holder">' +
            '<span class="select-label">' + escape(label) + '</span>' +
            (id_number ? '<span class="select-caption">ID Number: ' + escape(id_number) + '</span>' : '') +
            (email ? '<span class="select-caption">Email: ' + escape(email) + '</span>' : '') +
            '</div>';
        }
    },
    load: function(query, callback) {
        //if (!query.length) return callback();
        $.ajax({
            url: '/api/data/users',
            type: 'GET',
            dataType: 'json',
            data: {
                name: query
            },
            error: function() {
                callback();
            },
            success: function(res) {
                callback(res);
            }
        });
    }
  });
  