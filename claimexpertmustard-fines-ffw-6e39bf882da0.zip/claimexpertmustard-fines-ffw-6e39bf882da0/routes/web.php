<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/privacy-policy', 'PublicController@privacy')->name('privacy');
Route::get('/terms-and-conditions', 'PublicController@terms')->name('terms');
Route::get('/contact', 'PublicController@contact')->name('contact');
Route::post('/contact/store', 'ContactController@store')->name('contact-store');
Route::get('/not-verified', 'PublicController@unverified')->name('unverified');
Route::get('/not-approved', 'PublicController@notapproved')->name('notapproved');

Route::group(array('middleware' => ['auth', 'blocked' ,'isVerified', 'isApproved'] ), function() {
    Route::get('/', 'HomeController@status')->name('status');
    Route::get('/dashboard', 'HomeController@index')->name('home');
    Route::get('/fines', 'HomeController@fines')->name('fines');
    Route::get('/payments', 'HomeController@payments')->name('payments');
    
    Route::get('/payment', 'PaymentsController@payment')->name('payment');
    Route::post('/payment', 'PaymentsController@payment_store')->name('payment-store');
    Route::get('/payment/fines/select/{uuid}', 'PaymentsController@payment_select')->name('payment-select');
    Route::patch('/payment/fines/select/{uuid}', 'PaymentsController@payment_selected')->name('payment-selected');

    Route::get('/payment/fines/wallet/{uuid}', 'PaymentsController@payment_wallet')->name('payment-wallet');
    Route::get('/payment/fines/wallet/submit/{uuid}', 'WalletController@process_payment')->name('wallet-process-payment');
    Route::get('/payment/fines/{uuid}', 'PaymentsController@payment_step2')->name('payment-step2');
    Route::post('/payment/callback', 'PaymentsController@payment_process')->name('payment-callback');

    Route::get('/payment/thanks/{uuid}', 'PaymentsController@thanks')->name('payment-thanks');
    Route::get('/payment/receipt/{uuid}', 'PaymentsController@receipt')->name('payment-receipt');

    Route::get('/profile', 'HomeController@profile')->name('profile');
    Route::patch('/profile/{id}', 'HomeController@profile_update')->name('profile-update');

    Route::get('/wallet', 'WalletController@index')->name('wallet');
    Route::get('/wallet/activate/{id}', 'WalletController@activate')->name('wallet-activate');
    Route::get('/wallet/deactivate/{id}', 'WalletController@deactivate')->name('wallet-deactivate');

    Route::get('/wallet/purchase', 'WalletController@purchase')->name('wallet-purchase');
    Route::post('/wallet/purchase/create', 'WalletController@purchase_create')->name('wallet-purchase-create');

    Route::get('/wallet/payment/{uuid}', 'WalletController@payment_step2')->name('wallet-payment-step2');
    Route::post('/wallet/payment/callback', 'WalletController@payment_process')->name('wallet-payment-callback');
    
    Route::get('/wallet/payment/thanks/{uuid}', 'WalletController@thanks')->name('wallet-thanks');
    Route::get('/wallet/receipt/{uuid}', 'WalletController@receipt')->name('wallet-receipt');


});


Route::group(array('prefix' => 'admin', 'middleware' => ['auth', 'blocked', 'admin', 'isVerified'] ), function() {

    Route::get('/', ['uses' => 'AdminController@index', 'as' => 'admin-dashboard']);
    Route::get('/fines', 'AdminController@fines')->name('admin-fines');
    Route::get('/fines/search/', 'AdminController@search')->name('admin-fines-search');
    Route::get('/payments', 'AdminController@payments')->name('admin-payments');
    Route::get('/users', 'AdminController@users')->name('admin-users');
    Route::get('/users/search/', 'AdminController@userSearch')->name('admin-search-search');
    Route::get('/import', 'AdminController@import')->name('admin-import');
    Route::get('/imports', 'AdminController@imports')->name('admin-imports');
    Route::get('/wallets', 'AdminController@wallets')->name('admin-wallets');
   
    Route::post('/wallets/add-credit', 'AdminController@add_credit')->name('admin-add_credit');
    Route::post('/wallet/importer', 'WalletController@importer')->name('admin-importer-wallet');

    Route::post('/importer', 'ImportController@importer')->name('admin-importer');
    Route::get('/import/undo/{id}', 'AdminController@undo')->name('admin-import-undo');

    Route::get('/import/notifications/send', 'ImportController@notify_customers')->name('admin-import-notify');


    Route::get('/exporter/fines', 'ImportController@exporter')->name('admin-fines-exporter');
    Route::get('/exporter/users', 'ImportController@userExporter')->name('admin-users-exporter');

    Route::post('/importer/ids', 'IDListController@importer')->name('admin-importer-ids');
    Route::post('/importer/ids/add', 'IDListController@create')->name('admin-importer-create');

    Route::get('/users/convert/{id}', 'AdminController@convert')->name('admin-convert');
    Route::get('/users/downgrade/{id}', 'AdminController@downgrade')->name('admin-downgrade');

    Route::get('/users/block/{id}', 'AdminController@block')->name('admin-block');
    Route::get('/users/unblock/{id}', 'AdminController@unblock')->name('admin-unblock');
    Route::get('/users/approve/{id}', 'AdminController@approve')->name('admin-approve');
    Route::post('/users/importer', 'UserController@importer')->name('admin-importer-users');
    Route::post('/users/importerLg', 'UserController@importerLg')->name('admin-importer-users-lg');
    Route::post('/users/importerNew', 'UserController@importerNew')->name('admin-importer-users-new');

    Route::get('/users/verification/resend/{id}', 'AdminController@resendVerificationMail')->name('admin-resend-verify');

    Route::get('/setup', 'AdminController@setup')->name('admin-setup');

    Route::post('/setup/status/fines', 'AdminController@createFineStatus')->name('admin-finestatus');
    Route::post('/setup/status/payments', 'AdminController@createPaymentStatus')->name('admin-paymentstatus');

    Route::get('/setup/status/fines/delete/{id}', 'AdminController@destroyFineStatus')->name('admin-destroyFineStatus');
    Route::get('/setup/status/payments/delete/{id}', 'AdminController@destroyPaymentStatus')->name('admin-destroyPaymentStatus');

    Route::get('/users/sms/{id}', 'AdminController@smsTest')->name('admin-sms-test');

});


 /* API Routes */
Route::get('/api/data/users', 'DataController@users');
Route::get('/api/data/customers', 'DataController@customers');
Route::get('/api/data/fines', 'DataController@fines');