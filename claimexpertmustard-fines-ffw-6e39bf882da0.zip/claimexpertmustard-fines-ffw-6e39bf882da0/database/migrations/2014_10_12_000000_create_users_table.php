<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->uuid('uuid');
            
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('name')->nullable();
            $table->string('username')->nullable();
            $table->string('slug')->nullable();
            
            $table->string('email')->unique();
            $table->string('id_number')->unique();
            $table->string('mobile')->nullable();
            
            $table->string('password');
            $table->rememberToken();
            
            $table->integer('role_id')->default(2);
            $table->integer('status_id')->default(1);

            $table->integer('notify_me')->default(1);

            $table->timestamps();

            $table->index('uuid');
            $table->index('name');
            $table->index('role_id');
            $table->index('status_id');
            $table->index('id_number');
            $table->index('mobile');
            $table->index('email');
            $table->index('slug');
            $table->index('username');
            $table->index('notify_me');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
