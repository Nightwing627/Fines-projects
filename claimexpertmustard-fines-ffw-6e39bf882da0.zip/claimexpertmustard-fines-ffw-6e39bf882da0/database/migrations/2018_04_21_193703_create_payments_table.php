<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->increments('id');
            $table->uuid('uuid');
            
            $table->integer('user_id')->nullable();
            $table->string('id_number')->nullable();
            
            $table->decimal('amount', 13, 2);
            $table->string('remark')->nullable();
            
            $table->string('reference')->nullable();
            $table->string('linked_fines')->nullable();

            $table->string('pay_request_id')->nullable();
            $table->string('pay_checksum')->nullable();

            $table->integer('type_id')->default(1);
            $table->integer('status_id')->default(1);
            
            $table->timestamps();

            $table->index('uuid');
            $table->index('user_id');
            $table->index('type_id');
            $table->index('status_id');
            $table->index('amount');
            $table->index('id_number');
            $table->index('pay_request_id');
            $table->index('pay_checksum');

        });
    }



    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('payments');
    }
}
