<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFinesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fines', function (Blueprint $table) {
            $table->increments('id');
            $table->uuid('uuid');

            $table->integer('user_id')->nullable();
            $table->integer('status_id')->default(1)->nullable();
            $table->string('id_number')->nullable();
            $table->string('reg_number')->nullable();
            $table->string('notice_number')->nullable();
            $table->dateTime('offence_date')->nullable();
            $table->string('municipality')->nullable();
            $table->string('fine_classification')->nullable();

            $table->decimal('issued_amount', 13, 2)->nullable();
            $table->decimal('discount', 13, 2)->nullable();
            $table->decimal('discounted_amount', 13, 2)->nullable();
            $table->decimal('fe_discount_share', 13, 2)->nullable();
            $table->decimal('fe_admin_fee', 13, 2)->nullable();
            $table->decimal('total_payable', 13, 2)->nullable();

            $table->string('offence_location')->nullable();
            $table->mediumText('offence_description')->nullable();

            $table->integer('paid')->default(0);
            $table->integer('payment_id')->nullable();

            $table->string('fine_doc')->nullable();

            $table->integer('import_id')->nullable();

            $table->integer('notified')->default(0);
            

            $table->timestamps();

            $table->index('uuid');
            $table->index('id_number');
            $table->index('notice_number');
            $table->index('reg_number');
            $table->index('paid');
            $table->index('payment_id');
            $table->index('total_payable');
            $table->index('issued_amount');
            $table->index('import_id');
            $table->index('notified');

        });
    }


    
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('fines');
    }
}
