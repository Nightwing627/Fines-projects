<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddWallettotalToUser extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        
        Schema::table('users', function (Blueprint $table) {
            $table->integer('has_wallet')->default(0)->after('status_id');
            $table->decimal('wallet_balance', 13, 2)->default(0)->nullable()->after('has_wallet');
   
            $table->index('has_wallet');
            $table->index('wallet_balance');

        });
       
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        

    }
}
