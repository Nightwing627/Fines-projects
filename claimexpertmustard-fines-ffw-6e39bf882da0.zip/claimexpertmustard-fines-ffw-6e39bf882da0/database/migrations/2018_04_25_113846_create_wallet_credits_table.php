<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWalletCreditsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wallet_credits', function (Blueprint $table) {
            $table->increments('id');
            $table->uuid('uuid');
            $table->integer('user_id')->nullable();
            $table->decimal('amount', 13, 2);
            $table->mediumText('comment')->nullable();
            $table->integer('status_id')->default(1);

            $table->string('pay_request_id')->nullable();
            $table->string('pay_checksum')->nullable();

            $table->timestamps();

            $table->index('uuid');
            $table->index('user_id');
            $table->index('amount');
            $table->index('status_id');
            $table->index('pay_request_id');
            $table->index('pay_checksum');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wallet_credits');
    }
}
