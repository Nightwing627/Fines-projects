<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWalletImportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('wallet_imports', function (Blueprint $table) {
            $table->increments('id');
            
            $table->string('file')->nullable();
            $table->string('import_ref')->nullable();
            $table->integer('records')->nullable();
            $table->integer('user_id')->nullable();
            $table->integer('undone')->default(0)->nullable();

            $table->timestamps();

            $table->index('import_ref');
            $table->index('records');
            $table->index('user_id');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('wallet_imports');
    }
}
