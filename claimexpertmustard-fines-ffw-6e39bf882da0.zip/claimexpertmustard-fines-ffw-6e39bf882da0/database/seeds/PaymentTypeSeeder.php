<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PaymentTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      
        DB::table('payment_types')->delete();

        $items=[
            [
                'id'   => '1',
                'name' => 'Credit',
            ],
            [
                'id'   => '2',
                'name' => 'Wallet',
            ],
            [
                'id'   => '3',
                'name' => 'Refund',
            ],
        ];


        foreach($items as $item){
            DB::table('payment_types')->insert($item);
        }
        
    }
}
