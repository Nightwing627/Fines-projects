<?php

use Illuminate\Database\Seeder;

class FineStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        DB::table('fine_statuses')->delete();

        $items=[
            [
                'id'   => '1',
                'name' => 'Unpaid',
                'description' => 'Unpaid',
            ],
            [
                'id'   => '2',
                'name' => 'Paid',
                'description' => 'Paid',
            ],
            [
                'id'   => '3',
                'name' => 'Paid (Awaiting Clearance)',
                'description' => 'Paid (Awaiting Clearance)',
            ],
            [
                'id'   => '4',
                'name' => 'Notice',
                'description' => 'Notice',
            ],
            [
                'id'   => '5',
                'name' => 'Summons',
                'description' => 'Summons',
            ],
            [
                'id'   => '6',
                'name' => 'Other (1200)',
                'description' => 'Other (1200)',
            ],
            [
                'id'   => '7',
                'name' => 'Warrant',
                'description' => 'Warrant',
            ],
            [
                'id'   => '8',
                'name' => 'Settled',
                'description' => 'Settled',
            ],
            [
                'id'   => '9',
                'name' => 'Other',
                'description' => 'Other',
            ],
            [
                'id'   => '10',
                'name' => 'Withdrawn',
                'description' => 'Withdrawn',
            ],
            [
                'id'   => '11',
                'name' => 'SOR',
                'description' => 'SOR',
            ],
        ];


        foreach($items as $item){
            DB::table('fine_statuses')->insert($item);
        }

    }


}
