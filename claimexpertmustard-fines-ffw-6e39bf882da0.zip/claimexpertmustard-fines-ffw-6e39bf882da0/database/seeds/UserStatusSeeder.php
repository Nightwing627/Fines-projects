<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        DB::table('statuses')->delete();

        $items=[
            [
                'id'   => '1',
                'name' => 'Active',
                'description' => 'Active',
            ],
            [
                'id'   => '2',
                'name' => 'Blocked',
                'description' => 'Blocked',
            ],
            [
                'id'   => '3',
                'name' => 'Not Approved',
                'description' => 'Not Approved [ID Number not valid]',
            ],
        ];


        foreach($items as $item){
            DB::table('statuses')->insert($item);
        }


    }
}
