<?php

use Illuminate\Database\Seeder;

class PaymentStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
        DB::table('payment_statuses')->delete();

        $items=[
            [
                'id'   => '1',
                'name' => 'Unpaid',
                'description' => 'Unpaid',
            ],
            [
                'id'   => '2',
                'name' => 'Paid',
                'description' => 'Paid',
            ],
            [
                'id'   => '3',
                'name' => 'Payment Unprocessed',
                'description' => 'Payment Unprocessed',
            ],
            [
                'id'   => '4',
                'name' => 'Payment Processed',
                'description' => 'Payment Processed',
                
            ],
        ];


        foreach($items as $item){
            DB::table('payment_statuses')->insert($item);
        }

    }
}
