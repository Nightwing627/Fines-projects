<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         // Reset Auto Increment to 1
         $statement = "
         ALTER TABLE payment_statuses AUTO_INCREMENT = 1;
         ALTER TABLE fine_statuses AUTO_INCREMENT = 1;
         ALTER TABLE payment_types AUTO_INCREMENT = 1;
         ALTER TABLE statuses AUTO_INCREMENT = 1;
         ";

     DB::unprepared($statement);

      // Run the Actual Seeder Files
      Model::unguard();

      $this->call(FineStatusSeeder::class);
      $this->call(PaymentStatusSeeder::class);
      $this->call(PaymentTypeSeeder::class);
      $this->call(UserStatusSeeder::class);
     
      Model::reguard();

    }
}
