<?php
    return [
        'secret'     => env('PAYGATE_SECRET', 'secret'),
        'id'         => env('PAYGATE_ID', 'xs'),
        'currency'   => env('PAYGATE_CURRENCY', 'ZAR'),
        'locale'     => env('PAYGATE_LOCALE', 'en-za'),
        'return_url' => '',
        'notify_url' => '',
    ];