<?php
Route::get('pg', function(){
    echo 'Hello from the pg package!';
});