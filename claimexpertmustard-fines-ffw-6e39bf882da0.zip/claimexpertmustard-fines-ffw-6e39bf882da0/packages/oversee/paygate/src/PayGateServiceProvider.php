<?php

namespace Oversee\PayGate;

use Illuminate\Support\ServiceProvider;

class PayGateServiceProvider extends ServiceProvider
{

    protected $defer = TRUE;
   
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        
        include __DIR__.'/routes.php';

        $this->publishes([
            __DIR__ . "/config/paygate.php" => config_path('paygate.php'),
        ]);

    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        
        $this->app->singleton(PayGateWeb::class, function ($app) {
            return new PayGateWeb();
        });

    }


    public function provides()
    {
        return [PayGateWeb::class];
    }

}
