<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use NotificationChannels\Panacea\PanaceaMessage;
use NotificationChannels\Panacea\PanaceaChannel;

class SMSFineNotification extends Notification
{
    use Queueable;

    public $user;
    public $count;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($user, $count)
    {
        
        $this->user = $user;
        $this->count = $count;

    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return [PanaceaChannel::class, 'database'];
    }


    public function toPanacea($notifiable)
    {

        $turl = "https://ffw.finesupport.co.za";

        return (new PanaceaMessage())
            ->content("Hi " . $this->user->name . " we identified " . $this->count . " fine/s linked to you. Follow this link for more information: " . $turl);

    }

     /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {

         $turl = "https://ffw.finesupport.co.za";
         
         return [

            'type'      => "Fine SMS Notification",
            'user'      => $this->user->name,
            'count'     => $this->count,
            'url'       => $turl,
            'message'   => "Hi " . $this->user->name . " we identified " . $this->count . " fine/s linked to you. Follow this link for more information: " . $turl,
        
        ];
    }

}