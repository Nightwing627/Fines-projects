<?php

namespace App\Models;

use Emadadly\LaravelUuid\Uuids;
use Illuminate\Database\Eloquent\Model;

class Payments extends Model
{
    
    use Uuids;

    protected $with = ('fines');

    
    /**
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function status()
    {
        return $this->hasOne('App\Models\PaymentStatus', 'id', 'status_id');
    }


    /**
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function type()
    {
        return $this->hasOne('App\Models\PaymentType', 'id', 'type_id');
    }



    /**
     * @return HasMany
     */
    public function fines()
    {
        return $this->hasMany('App\Models\PaymentFines', 'payment_id', 'id');
    }

}
