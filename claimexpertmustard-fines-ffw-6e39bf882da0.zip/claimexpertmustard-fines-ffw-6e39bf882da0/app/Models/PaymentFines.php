<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentFines extends Model
{
    
    /**
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function payment()
    {
        return $this->hasOne('App\Models\Payments', 'id', 'payment_id');
    }


     /**
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function fine()
    {
        return $this->hasOne('App\Models\Fines', 'id', 'fine_id');
    }


}
