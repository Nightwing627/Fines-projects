<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserImports extends Model
{
    
// Relationships

    /**
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function creator()
    {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }


}
