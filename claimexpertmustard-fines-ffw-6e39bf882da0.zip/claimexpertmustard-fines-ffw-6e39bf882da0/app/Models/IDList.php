<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IDList extends Model
{
    
    public $table = 'id_list';

}
