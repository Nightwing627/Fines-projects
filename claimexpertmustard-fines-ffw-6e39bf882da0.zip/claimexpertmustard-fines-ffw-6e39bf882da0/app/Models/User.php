<?php

namespace App\Models;

use Emadadly\LaravelUuid\Uuids;
use Illuminate\Support\Facades\Auth;
use Illuminate\Notifications\Notifiable;
use Cviebrock\EloquentSluggable\Sluggable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;
    use Uuids;
    use Sluggable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name', 'last_name', 'name', 'email', 'password', 'id_number', 'mobile', 'notify_me',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];


    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable()
    {
        return [
            'slug' => [
                'source' => 'name'
            ],
            'username' => [
                'source' => 'name'
            ],

        ];
    }


   /**
     *  Check to see if the user account is blocked.
     *
     * @return bool
     */
    public function isVerified()
    {

        if (Auth::user()->verified == 1) {

            return true;
        }

        return false;

    }



    /**
     *  Check to see if the user account is blocked.
     *
     * @return bool
     */
    public function isBlocked()
    {

        if (Auth::user()->status_id == 2) {

            return true;
        }

        return false;

    }


    /**
     *  Check to see if the user account is blocked.
     *
     * @return bool
     */
    public function isApproved()
    {

        if (Auth::user()->status_id == 3) {

            return true;
        }

        return false;

    }




    /**
     *  Check to see if the user is an Admin.
     *
     * @return bool
     */
    public function isAdmin()
    {

        if (Auth::user()->role_id == 1) {

            return true;
        }

        return false;

    }

    
    // Relationships

    /**
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function status()
    {
        return $this->hasOne('App\Models\Status', 'id', 'status_id');
    }


    /**
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function role()
    {
        return $this->hasOne('App\Models\Role', 'id', 'role_id');
    }


    /**
     * @return HasMany
     */
    public function fines()
    {
        return $this->hasMany('App\Models\Fines', 'id_number', 'id_number');
    }

    
    /**
     * @return HasMany
     */
    public function payments()
    {
        return $this->hasMany('App\Models\Payments', 'user_id');
    }


    /**
     * @return HasMany
     */
    public function credits()
    {
        return $this->hasMany('App\Models\WalletCredits', 'user_id');
    }


    /**
     * @return HasMany
     */
    public function debits()
    {
        return $this->hasMany('App\Models\WalletDebits', 'user_id');
    }



    public function routeNotificationForPanacea()
    {

        $number = $this->mobile;

        return $number;

    }

}
