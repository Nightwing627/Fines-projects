<?php

namespace App\Jobs;

use App\Models\User;
use Ramsey\Uuid\Uuid;
use App\Mail\UserWelcome;
use Illuminate\Bus\Queueable;
use App\Mail\UserImportComplete;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

// class ImportUserRecords
class ImportUserRecords implements ShouldQueue
{
    // use Dispatchable, SerializesModels;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $import;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($import)
    {
        
        $this->import = $import;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        
        $file = base_path() . '/public/'. $this->import->file;
        $customerArr = $this->csvToArray($file);

         for ($i = 0; $i < count($customerArr); $i ++) {

            $checkUser = DB::table('users')->where('id_number', $customerArr[$i]['IdentificationNumber'])->exists();
            $checkEmail = DB::table('users')->where('email', $customerArr[$i]['Email'])->exists();

            if($checkUser != 'false' || $checkEmail != 'false') {

                $now = date("Y-m-d H:i:s");

                $dataArray[$i] =
                [
                  'uuid' => Uuid::uuid4()->toString(),
                  'id_number' => $customerArr[$i]['IdentificationNumber'],
                  'first_name' => $customerArr[$i]['FirstName'],
                  'last_name' => $customerArr[$i]['LastName'],
                  'name' => $customerArr[$i]['FirstName'] . ' ' . $customerArr[$i]['LastName'],
                  'email' => $customerArr[$i]['Email'],                                  
                  'mobile' => $customerArr[$i]['Mobile'],
                  'password' => Hash::make($customerArr[$i]['IdentificationNumber']),
                  'status_id' => 1,
                  'verified' => 1,
                  'created_at' => $now,
                ];             
                
                User::insert($dataArray[$i]);

                $user = User::where('email',$customerArr[$i]['Email'])->first();

                Mail::to($user->email)
                ->send(new UserWelcome($user));

            }

        }


        Mail::to('finesportal.contact@claimexpert.co.za')
        // ->cc('finesportal.contact@claimexpert.co.za')
        ->bcc('stan@mustard.agency')
        ->send(new UserImportComplete($this->import));


    }



    function csvToArray($filename = '', $delimiter = ',')
     {
         if (!file_exists($filename) || !is_readable($filename))
             return false;
     
         $header = null;
         $data = array();
         if (($handle = fopen($filename, 'r')) !== false)
         {
             while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
             {
                 if (!$header)
                     $header = $row;
                 else

                 $data[] = array_combine($header, $row);
                     
             }
             fclose($handle);
         }
     
         return $data;
     }
     

}
