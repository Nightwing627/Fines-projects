<?php

namespace App\Jobs;

ini_set('memory_limit', -1);
set_time_limit(0);

use App\Models\User;
use App\Models\Fines;
use App\Models\Imports;
use App\Mail\ImportComplete;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\DB;
use App\Jobs\SendFineNotifications;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
// use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Foundation\Bus\DispatchesJobs;


class ProcessFineImports 
{
    use DispatchesJobs;

    public $import;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($import)
    {
        
        $this->import = $import;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        Excel::filter('chunk')->load(base_path() . '/public/'. $this->import->file)->chunk(250, function($results)
        {

                foreach($results as $line)
                {

                    $import = DB::table('imports')->orderBy('created_at', 'desc')->first();
                    $checkfine = Fines::where('notice_number',$line->noticenumber)->first();

                    if(!$checkfine) {

                        $fine = New Fines();

                        $fine->id_number = $line->identificationnumber;
                        $fine->reg_number = $line->registrationnumber;
                        $fine->notice_number = $line->noticenumber;
                        $fine->offence_date = $line->offencedate;
                        $fine->municipality = $line->municipality;
                        $fine->fine_classification = $line->fineclassification;
    
                        $fine->issued_amount = $line->issuedamount;
                        $fine->discount = $line->discount;
                        $fine->discounted_amount = $line->discountedamount;
                        $fine->total_payable = $line->totalpayable;
    
                        $fine->offence_location = $line->offencelocation;
                        $fine->offence_description = $line->offencedescription;
                        
                        if($line->finedoc) {
                                $link = $line->finedoc;
                                if (filter_var($link, FILTER_VALIDATE_URL) === FALSE) {
                                    // skip option if invalid
                                } else {
                                    // if a document URL is supplied is valid, then store it
                                    $fine->fine_doc = $line->finedoc;
                                }
                        }
    
                            // check if a fine status was supplied else set to 1
                        if($line->status) {
                            $fine->status_id = $line->status;
                        } else {
                            $fine->status_id = 1;
                        }
    
                        $fine->fine_doc = $line->finedoc;
                        $fine->import_id = $this->import->id;
                    
                        $fine->save();

                    } else {

                        $checkfine->id_number = $line->identificationnumber;
                        $checkfine->reg_number = $line->registrationnumber;
                        $checkfine->notice_number = $line->noticenumber;
                        $checkfine->offence_date = $line->offencedate;
                        $checkfine->municipality = $line->municipality;
                        $checkfine->fine_classification = $line->fineclassification;
    
                        $checkfine->issued_amount = $line->issuedamount;
                        $checkfine->discount = $line->discount;
                        $checkfine->discounted_amount = $line->discountedamount;
                        $checkfine->total_payable = $line->totalpayable;
    
                        $checkfine->offence_location = $line->offencelocation;
                        $checkfine->offence_description = $line->offencedescription;
                        
                        if($line->finedoc) {
                                $link = $line->finedoc;
                                if (filter_var($link, FILTER_VALIDATE_URL) === FALSE) {
                                    // skip option if invalid
                                } else {
                                    // if a document URL is supplied is valid, then store it
                                    $checkfine->fine_doc = $line->finedoc;
                                }
                        }
    
                            // check if a fine status was supplied else set to 1
                        if($line->status) {
                            $checkfine->status_id = $line->status;
                        } else {
                            $checkfine->status_id = 1;
                        }
    
                        $checkfine->fine_doc = $line->finedoc;
                        $checkfine->import_id = $this->import->id;
                    
                        $checkfine->save();

                    }

            }

        },
        false
        );

        // count only the fines that were created.
        $fines = Fines::where('import_id',$this->import->id)->count();
        $this->import->records = $fines;
        $this->import->save();

        Mail::to('stan@mustard.agency')
            // ->cc('finesportal.contact@claimexpert.co.za')
            ->bcc('stan@mustard.agency')
            ->send(new ImportComplete($this->import));

    }
    
}
