<?php

namespace App\Jobs;

use App\Models\User;
use App\Models\Fines;
use Illuminate\Bus\Queueable;
use App\Mail\FinesNotification;
use Illuminate\Support\Facades\Mail;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use App\Notifications\SMSFineNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SendFineNotifications
{
    use Dispatchable, SerializesModels;

    protected $users;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($users)
    {
        
        $this->users = $users;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        foreach($this->users as $u)
        {

            $user = User::where('id',$u->id)->first();

            if($user->notify_me == 1) {

                //get fines (that are not paid and that haven't been notified already)
                $fines = Fines::where('id_number', $user->id_number)->where('paid',0)->where('status_id','!=',2)->where('notified',0)->get();
                
                //get the fines count
                $count = $fines->count();

                if($count == 0) {

                    // do nothing!

                } else {

                     // send notification email
                    Mail::to($user->email)
                    ->bcc('stan@mustard.agency')
                    ->send(new FinesNotification($user, $count));

                    // SMS all customers
                    $user->notify(new SMSFineNotification($user, $count));

                    // update fine status
                    foreach($fines as $f) {
                    $fine = Fines::where('id', $f->id)->first();
                    $fine->notified = 1;
                    $fine->save();
                    }
                    
                }

               

            } else {

            }

        }

    }
}
