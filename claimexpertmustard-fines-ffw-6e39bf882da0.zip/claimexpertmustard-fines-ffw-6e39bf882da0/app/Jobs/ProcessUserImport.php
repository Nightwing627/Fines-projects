<?php

namespace App\Jobs;

ini_set('memory_limit', -1);
set_time_limit(0);

use App\Models\User;
use App\Mail\UserWelcome;
use Illuminate\Bus\Queueable;
use App\Mail\UserImportComplete;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class ProcessUserImport implements ShouldQueue
{
    use Dispatchable;

    protected $import;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($import)
    {
        
        $this->import = $import;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        Excel::filter('chunk')->load(base_path() . '/public/'. $this->import->file)->chunk(50, function($results)
        {

                foreach($results as $line)
                {

                    $import = DB::table('idnumber_imports')->orderBy('created_at', 'desc')->first();
                    $checkUser = User::where('id_number',$line->identificationnumber)->first();

                    if(!$checkUser) {

                        $user = New User();

                        $user->id_number = $line->identificationnumber;
                        $user->first_name = $line->firstname;
                        $user->last_name = $line->lastname;
                        $user->name = $line->firstname . ' ' . $line->name;
                        $user->email = $line->email;                       
                        $user->mobile = $line->mobile;
                        
                        $user->password = Hash::make($line->identificationnumber);
                        $user->status_id = 1;
                        $user->verified = 1;
                        $user->save();

                        Mail::to($user->email)
                        ->bcc('stan@mustard.agency')
                        ->send(new UserWelcome($this->user));

                    } else {

                        $checkUser->id_number = $line->identificationnumber;
                        $checkUser->first_name = $line->firstname;
                        $checkUser->last_name = $line->lastname;
                        $checkUser->name = $line->firstname . ' ' . $line->name;
                        $checkUser->email = $line->email;
                        $checkUser->mobile = $line->mobile;
                        
                        $checkUser->password = Hash::make($line->identificationnumber);
                        $checkUser->status_id = 1;
                        $checkUser->verified = 1;
                        $checkUser->save();

                    }

                }

        },
        false
        );
        
        Mail::to('finesportal.contact@claimexpert.co.za')
            // ->cc('finesportal.contact@claimexpert.co.za')
            ->bcc('stan@mustard.agency')
            ->send(new UserImportComplete($this->import));

    }
}
