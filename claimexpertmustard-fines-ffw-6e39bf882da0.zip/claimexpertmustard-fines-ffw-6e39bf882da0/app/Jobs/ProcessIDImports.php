<?php

namespace App\Jobs;

ini_set('memory_limit', -1);
set_time_limit(0);

use App\Models\IDList;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class ProcessIDImports implements ShouldQueue
{
    use Dispatchable;

    protected $import;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($import)
    {
        
        $this->import = $import;

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {


        Excel::filter('chunk')->load(base_path() . '/public/'. $this->import->file)->chunk(250, function($results)
        {

                foreach($results as $line)
                {

                    $import = DB::table('idnumber_imports')->orderBy('created_at', 'desc')->first();

                    $fine = New IDList();
                    $fine->id_number = $line->identificationnumber;                       
                    $fine->save();

                }

        },
        false
        );


        // count only the fines that were created.
        // $fines = Fines::where('import_id',$this->import->id)->count();
        // $this->import->records = $fines;
        // $this->import->save();


        // Mail::to('stan@mustard.agency')
        //     // ->cc('finesportal.contact@claimexpert.co.za')
        //     // ->bcc('stan@mustard.agency')
        //     ->send(new ImportComplete($this->import));


    }
    
}
