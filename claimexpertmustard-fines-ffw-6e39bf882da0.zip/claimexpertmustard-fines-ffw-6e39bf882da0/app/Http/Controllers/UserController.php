<?php

namespace App\Http\Controllers;

ini_set('memory_limit', -1);
set_time_limit(0);

use App\Models\User;
use Ramsey\Uuid\Uuid;
use App\Models\UserImports;
use Illuminate\Http\Request;
use App\Jobs\ImportUserRecords;
use App\Jobs\ProcessUserImport;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class UserController extends Controller
{
    
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function importer(Request $request)
    {


        if($request->file('file'))
        {
                  $path = $request->file('file')->getRealPath();
                  $data = Excel::load($path, function($reader)
            {
                  })->get();
  
            if(!empty($data) && $data->count())
            {
              foreach ($data->toArray() as $row)
              {
                if(!empty($row))
                {
                  $dataArray[] =
                  [
                    'id_number' => $row['identificationnumber'],
                    'name' => $row['firstname'] . ' ' . $row['lastname'],
                    'email' => $row['email'],                                  
                    'mobile' => $row['mobile'],
                    'password' => Hash::make($row['identificationnumber']),
                    'status_id' => 1,
                    'verified' => 1,
                  ];
                }
            }
            if(!empty($dataArray))
            {
               User::insert($dataArray);
               return back();
             }
           }
         }


    }


     public function importerNew(Request $request)
     {
         
        if (Input::hasFile('file')) {

            // create the import
            $attachment = Input::file('file');
            $filename = 'import_' . str_random(20) . '.' . $attachment->getClientOriginalExtension();
            
            $import = New UserImports();
            $import->file = 'uploads/imports/users/' . $filename;
            $import->user_id = Auth::user()->id;
            $import->import_ref = $filename;
            
            $file = $request->file('file')->move(
                base_path() . '/public/uploads/imports/users/' , $filename
            );

            $import->save();

            // Process the file import
            $this->dispatch(new ImportUserRecords($import));

            return Redirect::back()->with('success', 'Your import is being processed and you will receive an email once it has completed.');


        } else {

            return Redirect::back()->with('warning', 'No file selected!');

        }

     }



     function csvToArray($filename = '', $delimiter = ',')
     {
         if (!file_exists($filename) || !is_readable($filename))
             return false;
     
         $header = null;
         $data = array();
         if (($handle = fopen($filename, 'r')) !== false)
         {
             while (($row = fgetcsv($handle, 1000, $delimiter)) !== false)
             {
                 if (!$header)
                     $header = $row;
                 else
                     $data[] = array_combine($header, $row);
             }
             fclose($handle);
         }
     
         return $data;
     }




}
