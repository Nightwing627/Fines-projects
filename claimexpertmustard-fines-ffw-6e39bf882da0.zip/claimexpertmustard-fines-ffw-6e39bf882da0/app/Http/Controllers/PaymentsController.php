<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Fines;
use App\Models\Payments;
use App\Models\PaymentFines;
use App\Modules\PayGate\PayGate_PayWeb3;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class PaymentsController extends Controller
{
    
 /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment()
    {

        $user = Auth::user();

        $fines = Fines::where('id_number',$user->id_number)->where('paid',0)->get();
      
        return view('payment', compact('user', 'fines'));
    
    }


  

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment_store(Request $request)
    {

        $user = Auth::user();


        if($request->input('ids')) {

            $payment = New Payments();

            $payment->user_id = $user->id;
            $payment->id_number = $user->id_number;
            $payment->amount = 0;
          
            $payment->save();
    
            $ids = $request->input('ids', array(1));

            foreach ($ids as $id){

                $getfine = Fines::where('id',$id)->first();
                $amount = $getfine->total_payable;
                
                $linkedFine = New PaymentFines();

                $linkedFine->payment_id = $payment->id;
                $linkedFine->fine_id = $getfine->id;

                $linkedFine->save();

            }
    

            $finesList = implode(",",$ids);
    
            $payment->linked_fines = $finesList;
    
            $finesCollect = collect();
        
            foreach ($ids as $id){
                $getfine = Fines::where('id',$id)->first();
                $amount = $getfine->total_payable;
                $finesCollect->push($amount);
            }
    
            $paymentTotal = $finesCollect->sum();
            $payment->amount = $paymentTotal + 10;
    
            $payment->save();
           
            return redirect()->route('payment-select',$payment->uuid);

        } else {

            return Redirect::back()->with('warning', 'No fines selected!');

        }

    
    }


     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment_select($uuid)
    {

        $user = Auth::user();
        $payment = Payments::uuid($uuid);
        $nowtime = now();

        return view('payments.select', compact('user', 'payment', 'nowtime'));
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment_selected($uuid, Request $request)
    {

       
        $user = Auth::user();

        if($request->input('type_id')) {

            $payment = Payments::uuid($uuid);
            
            $payment->type_id = $request->input('type_id');
            $payment->save();

            if($payment->type_id == 1) {

                return redirect()->route('payment-step2',$payment->uuid);

            } else {

                return redirect()->route('payment-wallet',$payment->uuid);

            }

        } else {

            return Redirect::back()->with('warning', 'No type selected!');

        }
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment_wallet($uuid)
    {

        $user = Auth::user();
        $payment = Payments::uuid($uuid);
        $nowtime = now();

        return view('payments.wallet', compact('user', 'payment', 'nowtime'));
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment_step2($uuid)
    {

        $user = Auth::user();
        $payment = Payments::uuid($uuid);
        $nowtime = now();
        $return_url = "https://ffw.finesupport.co.za/payment/callback";
        $encryption_key = 'secret';
        
        $paymentCount = $payment->fines->count();

        if($paymentCount == 1) {
             $payFine = PaymentFines::where('payment_id',$payment->id)->first();
             $theFine = Fines::where('id',$payFine->fine_id)->first();
             $reference = $theFine->notice_number;
            } else {
                $reference = $user->id_number . '_' . $paymentCount;
            }

        $mandatoryFields = array(
            'PAYGATE_ID'        => filter_var('1021845100016', FILTER_SANITIZE_STRING),
            'REFERENCE'         => filter_var($reference, FILTER_SANITIZE_STRING),
            // 'AMOUNT'            => filter_var(1, FILTER_SANITIZE_NUMBER_INT),
            'AMOUNT'            => filter_var($payment->amount, FILTER_SANITIZE_NUMBER_INT),
            'CURRENCY'          => filter_var('ZAR', FILTER_SANITIZE_STRING),
            'RETURN_URL'        => filter_var($return_url, FILTER_SANITIZE_URL),
            'TRANSACTION_DATE'  => filter_var($nowtime, FILTER_SANITIZE_STRING),
            'LOCALE'            => filter_var('en-za', FILTER_SANITIZE_STRING),
            'COUNTRY'           => filter_var('ZAF', FILTER_SANITIZE_STRING),
            'EMAIL'             => filter_var($user->email, FILTER_SANITIZE_EMAIL)
        );
    
        $optionalFields = array(
            'PAY_METHOD'        => (isset($_POST['PAY_METHOD']) ? filter_var($_POST['PAY_METHOD'], FILTER_SANITIZE_STRING) : ''),
            'PAY_METHOD_DETAIL' => (isset($_POST['PAY_METHOD_DETAIL']) ? filter_var($_POST['PAY_METHOD_DETAIL'], FILTER_SANITIZE_STRING) : ''),
            'NOTIFY_URL'        => (isset($_POST['NOTIFY_URL']) ? filter_var($_POST['NOTIFY_URL'], FILTER_SANITIZE_URL) : ''),
            'USER1'             => (isset($_POST['USER1']) ? filter_var($_POST['USER1'], FILTER_SANITIZE_URL) : ''),
            'USER2'             => (isset($_POST['USER2']) ? filter_var($_POST['USER2'], FILTER_SANITIZE_URL) : ''),
            'USER3'             => (isset($_POST['USER3']) ? filter_var($_POST['USER3'], FILTER_SANITIZE_URL) : ''),
            'VAULT'             => (isset($_POST['VAULT']) ? filter_var($_POST['VAULT'], FILTER_SANITIZE_NUMBER_INT) : ''),
            'VAULT_ID'          => (isset($_POST['VAULT_ID']) ? filter_var($_POST['VAULT_ID'], FILTER_SANITIZE_STRING) : '')
        );

        $data = array_merge($mandatoryFields, $optionalFields);

        // Set the session vars once we have cleaned the inputs
        $_SESSION['pgid']      = $data['PAYGATE_ID'];
        $_SESSION['reference'] = $data['REFERENCE'];
        $_SESSION['key']       = $encryption_key;

        //process the payment
        $PayWeb3 = new PayGate_PayWeb3();
        $PayWeb3->setEncryptionKey($encryption_key);
        $PayWeb3->setInitiateRequest($data);
        $returnData = $PayWeb3->doInitiate();

        $isValid = $PayWeb3->validateChecksum($PayWeb3->initiateResponse);

        // if we get a valid response back, continue
        if($isValid){ 
    
            $request_id = $PayWeb3->processRequest['PAY_REQUEST_ID'];
            $checksum = $PayWeb3->processRequest['CHECKSUM'];

            // update the payment with the response data
            $payment->pay_request_id =  $request_id;
            $payment->pay_checksum =  $checksum;
            $payment->reference = $reference;
            $payment->save();

            // now process the payment
            $responseResults = array(
                'PAY_REQUEST_ID' => $request_id,
                'CHECKSUM' => $checksum,
            );

            $responseData = array_merge($mandatoryFields, $optionalFields,$responseResults);
            $url = 'https://secure.paygate.co.za/payweb3/process.trans';


            return view('payments.step2', compact('user', 'payment', 'responseData', 'url'));

          
        } else { // else redirect with the error

            $lastError = $PayWeb3->lastError;
            return Redirect::back()->with('warning', 'There was an issue with your payment: ' . $lastError);
        
        }


    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment_process(Request $request)
    {

            // 1 => 'Approved',
            // 2 => 'Declined',
            // 4 => 'Cancelled'

        $PAY_REQUEST_ID = $request->input('PAY_REQUEST_ID');
        $TRANSACTION_STATUS = $request->input('TRANSACTION_STATUS');
        $CHECKSUM = $request->input('CHECKSUM');

        $payment = Payments::where('pay_request_id',$PAY_REQUEST_ID)->first();

        if($payment) {

            if($TRANSACTION_STATUS == 4) {
                return redirect()->route('payments')->with('warning', 'Your Payment was cancelled!');
            }

            if($TRANSACTION_STATUS == 2) {
                return redirect()->route('payments')->with('warning', 'Your Payment was declined!');
            }


            if($TRANSACTION_STATUS == 1) {

                $payment->status_id = 2;
                $payment->save();

                 // now go and update each fine's status!
                $fines = PaymentFines::where('payment_id',$payment->id)->get();

                foreach ($fines as $fine) {

                    $getfine = Fines::where('id',$fine->fine_id)->first();
                    $getfine->status_id = 3; // fine status - Paid (Awaiting Confirmation)
                    $getfine->payment_id = $payment->id;
                    $getfine->paid = 1;
                    $getfine->save();

                }

                return redirect()->route('payment-thanks',$payment->uuid)->with('success', 'Your Payment was successful!');
            
            }

        } else {

            return redirect()->route('payments')->with('warning', 'We could not locate your transaction.');

        }

    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function thanks($uuid)
    {

        $user = Auth::user();
        $payment = Payments::uuid($uuid);        
        $customer = User::where('id', $payment->user_id)->first();

        return view('payments.thankyou', compact('user', 'payment', 'customer'));
    
    }


      /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function receipt($uuid)
    {

        $user = Auth::user();
        $payment = Payments::uuid($uuid);        
        $customer = User::where('id', $payment->user_id)->first();

        return view('payments.receipt', compact('user', 'payment', 'customer'));
    
    }


}
