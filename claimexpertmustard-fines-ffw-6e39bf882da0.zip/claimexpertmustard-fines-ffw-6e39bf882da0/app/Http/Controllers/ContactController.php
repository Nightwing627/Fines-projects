<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactFormNotification;
use Illuminate\Support\Facades\Redirect;

class ContactController extends Controller
{
   
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $user = Auth::user();

        $contact = New Contact();
        $contact->first_name = $request->input('first_name');
        $contact->last_name = $request->input('last_name');
        $contact->email = $request->input('email');
        $contact->phone = $request->input('phone');
        $contact->message = $request->input('message');
        
        if($user) {
            $contact->user_id = $user->id;
        }

        $contact->save();

        Mail::to($contact->email)
        ->cc('finesportal.contact@claimexpert.co.za')
        ->bcc('stan@mustard.agency')
        ->send(new ContactFormNotification($contact));

        return Redirect::back()->with('success', 'Thank you for your enquiry!');

    }

  
}
