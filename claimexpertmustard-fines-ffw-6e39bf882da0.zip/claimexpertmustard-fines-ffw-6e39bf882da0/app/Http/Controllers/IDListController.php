<?php

namespace App\Http\Controllers;


ini_set('memory_limit', -1);
set_time_limit(0);

use App\Models\IDList;
use Illuminate\Http\Request;
use App\Jobs\ProcessIDImports;
use App\Models\IdnumberImports;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class IDListController extends Controller
{
    
 /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function importer(Request $request)
    {

        if (Input::hasFile('file')) {

            // create the import
            $attachment = Input::file('file');
            $filename = 'import_' . str_random(20) . '.' . $attachment->getClientOriginalExtension();
            
            $import = New IdnumberImports();
            $import->file = 'uploads/imports/ids/' . $filename;
            $import->user_id = Auth::user()->id;
            $import->import_ref = $filename;
            
            $file = $request->file('file')->move(
                base_path() . '/public/uploads/imports/ids/' , $filename
            );

            $import->save();

            // Process the file import

            Excel::filter('chunk')->load(base_path() . '/public/'. $import->file)->chunk(250, function($results)
            {
    
                    foreach($results as $line)
                    {
    
                        $import = DB::table('idnumber_imports')->orderBy('created_at', 'desc')->first();
    
                        $fine = New IDList();
                        $fine->id_number = $line->identificationnumber;                       
                        $fine->save();
    
                    }
    
            },
            false
            );

            // $this->dispatch(new ProcessIDImports($import));

            return Redirect::back()->with('success', 'Your import is complete.');
           
        } else {

            return Redirect::back()->with('warning', 'No file selected!');

        }


    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {


        if($request->input('id_number')) {


            $checkId = IDList::where('id_number',$request->input('id_number'))->first();

            if($checkId) {

                return Redirect::back()->with('warning', 'That ID Number has already been added!');

            } else {

                $user = Auth::user();
        
                $fine = New IDList();
                $fine->id_number = $request->input('id_number');                       
                $fine->save();
    
                return Redirect::back()->with('success', 'ID Number added!');

            }

        
        } else {

            return Redirect::back()->with('warning', 'Please enter an ID Number!');

        }

    }


}
