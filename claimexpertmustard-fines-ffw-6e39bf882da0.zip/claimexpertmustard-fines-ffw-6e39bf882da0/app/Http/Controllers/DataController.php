<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DataController extends Controller
{
    
    /**
     * All Customers
     *
     * @return \Illuminate\Http\Response
     */
    public function customers()
    {

        $customers = DB::table('users')
            ->where('id','!=',0)
            ->where('has_wallet','=',1)
            ->orderBy('users.name', 'asc')
            ->get([
                DB::raw('users.name as name'),
                DB::raw('users.id_number as id_number'),
                DB::raw('users.email as email'),
                DB::raw('users.id as id'),
            ])
            ->toArray();

        return $customers;
    }


  /**
     * All Fines
     *
     * @return \Illuminate\Http\Response
     */
    public function fines()
    {

        $customers = DB::table('fines')
            ->where('id','!=',0)
            ->orderBy('fines.notice_number', 'asc')
            ->get([
                DB::raw('fines.notice_number as notice_number'),
                DB::raw('fines.id_number as id_number'),
                DB::raw('fines.reg_number as reg_number'),
                DB::raw('fines.uuid as uuid'),
                DB::raw('fines.id as id'),
            ])
            ->toArray();

        return $customers;
    }


        /**
     * All Customers
     *
     * @return \Illuminate\Http\Response
     */
    public function users()
    {

        $users = DB::table('users')
            ->where('id','!=',0)
            ->orderBy('users.name', 'asc')
            ->get([
                DB::raw('users.name as name'),
                DB::raw('users.id_number as id_number'),
                DB::raw('users.email as email'),
                DB::raw('users.id as id'),
            ])
            ->toArray();

        return $users;
    }



}
