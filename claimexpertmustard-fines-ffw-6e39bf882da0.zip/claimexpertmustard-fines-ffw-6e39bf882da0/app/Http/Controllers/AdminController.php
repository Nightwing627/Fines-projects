<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Fines;
use App\Models\IDList;
use App\Models\Imports;
use App\Models\Payments;

use App\Models\FineStatus;
use App\Models\WalletDebits;
use Illuminate\Http\Request;
use App\Models\PaymentStatus;
use App\Models\WalletCredits;
use Illuminate\Support\Facades\DB;
use App\Notifications\SMSBuyerTest;
use App\Notifications\UserApproved;
use Illuminate\Support\Facades\Auth;
use Rap2hpoutre\FastExcel\FastExcel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Jrean\UserVerification\Facades\UserVerification;

class AdminController extends Controller
{
    
/**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $user = Auth::user();
        $pagetitle = "Admin Dashboard";
       
        return view('admin.index', compact('user', 'pagetitle'));
    
    }


     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function fines()
    {

        $user = Auth::user();
        $fines = Fines::all();
        $pagetitle = "Search for Fines";
      
        return view('admin.fines', compact('user', 'fines', 'pagetitle'));
    
    }



     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {

        $user = Auth::user();

        $type = 0;


        if($request->input('fine')) {

            $fine = Fines::where('id',$request->input('fine'))->first();
            $query = $fine->notice_number;
            $type = 1;
            
        }


        if($request->input('id_number')) {

            $query = $request->input('id_number');
            $type = 2;
            $fines = Fines::where('id_number',$request->input('id_number'))->get();
            
        }


        if( $request->input('id_number') && $request->input('fine') ) {

            $fine = Fines::where('id',$request->input('fine'))->first();
            $fines = Fines::where('id_number',$request->input('id_number'))->get();

            $query = $request->input('id_number') . ' and ' . $fine->notice_number ;
            $type = 3;
           
        }


        if($type == 0 ) {

            return Redirect::back()->with('warning', 'Please enter search criteria!');

        }


        $pagetitle = "Fine Search Result";
      
        return view('admin.fines.result', compact('user', 'query', 'type', 'fines', 'fine', 'pagetitle'));
    
    }



 /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function userSearch(Request $request)
    {

        if( $request->input('user') ) {

            $user = User::where('id',$request->input('user'))->first();

            $pagetitle = "User Search Result";
      
            return view('admin.users.result', compact('user',  'pagetitle'));
        
        } else {

            return Redirect::back()->with('warning', 'Please enter search criteria!');

        }
     
    }




    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payments()
    {

        $user = Auth::user();
        $payments = Payments::all();
        $pagetitle = "All Payments";
      
        return view('admin.payments', compact('user', 'payments', 'pagetitle'));
    
    }



   /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function users()
    {

        $user = Auth::user();
        $users = User::all();
        $idnumbers = IDList::all();
        $pagetitle = "All Registered Users";
      
        return view('admin.users', compact('user', 'users', 'idnumbers', 'pagetitle'));
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function import()
    {

        $user = Auth::user();
        $pagetitle = "Import New Fines";
      
        return view('admin.import', compact('user', 'pagetitle'));
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function imports()
    {

        $user = Auth::user();
        $imports = Imports::all();
        $pagetitle = "Import History";
      
        return view('admin.imports', compact('user', 'pagetitle', 'imports'));
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function wallets()
    {

        $user = Auth::user();
        $pagetitle = "User Wallets";

        $credits = WalletCredits::all();
        $debits = WalletDebits::all();

        $users = User::where('has_wallet', 1)->get();
      
        return view('admin.wallets.index', compact('user', 'pagetitle', 'credits', 'debits', 'users'));
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function add_credit(Request $request)
    {

        if( $request->input('amount') || $request->input('user_id') ) {

            $user = User::where('id',$request->input('user_id'))->first();
        
            // save a new wallet credit transaction
            $credit = New WalletCredits();
            $credit->user_id = $user->id;
            $credit->amount = $request->input('amount');
            $credit->comment = "Credit Added by System Admin";
            $credit->status_id = 2;
            $credit->save();

            // get the new wallet balance
            $oldWalletAmount = $user->wallet_balance;
            $newWalletAmount = $user->wallet_balance + $credit->amount;

            // update the user's wallet
            $user->wallet_balance = $newWalletAmount;
            $user->save();        
            
            return Redirect::back()->with('success', 'Credit Amount added!');
            
        } else {

            return Redirect::back()->with('warning', 'Please enter a credit amount and/or customer!');

        }

    }





     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function undo($id)
    {

        $import = Imports::find($id);

        $fines = Fines::where('import_id',$import->id)->get();

        foreach($fines as $fine) {
            $thefine = Fines::where('id',$fine->id)->first();
            $thefine->delete();
        }

        $import->undone = 1;
        $import->save();        
      
        return Redirect::back()->with('success', 'File import undone. All fines have been removed.');
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function convert($id)
    {

        $user = User::find($id);

        $user->role_id = 1;
        $user->save();        
      
        return Redirect::back()->with('success', 'User has been converted to an Admin User.');
    
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function downgrade($id)
    {

        $user = User::find($id);

        $user->role_id = 2;
        $user->save();        
      
        return Redirect::back()->with('success', 'User has been downgraded to a Customer.');
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function block($id)
    {

        $user = User::find($id);

        $user->status_id = 2;
        $user->save();        
      
        return Redirect::back()->with('success', 'User has been blocked.');
    
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function unblock($id)
    {

        $user = User::find($id);

        $user->status_id = 1;
        $user->save();        
      
        return Redirect::back()->with('success', 'User has been unblocked.');
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function approve($id)
    {

        $user = User::find($id);

        $user->status_id = 1;
        $user->save();        

        $user->notify(new UserApproved($user));

        return Redirect::back()->with('success', 'User has been approved.');
    
    }






    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function setup()
    {

        $user = Auth::user();
        $pagetitle = "System Setup";

        $fineStatuses = FineStatus::all();
        $paymentStatuses = PaymentStatus::all();
      
        return view('admin.setup.index', compact('user', 'pagetitle', 'fineStatuses', 'paymentStatuses'));
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function createFineStatus(Request $request)
    {

        $checkStatus = FineStatus::where('name',$request->input('name'))->first();

        if($checkStatus) {

            return Redirect::back()->with('warning', $request->input('name') . ' already exists!');

        } else {

            $status = New FineStatus();

            $status->name = $request->input('name');
            $status->save();        
          
            return Redirect::back()->with('success', $status->name . ' has been added!');

        }

    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function createPaymentStatus(Request $request)
    {

        $checkStatus = PaymentStatus::where('name',$request->input('name'))->first();

        if($checkStatus) {

            return Redirect::back()->with('warning', $request->input('name') . ' already exists!');

        } else {

            $status = New PaymentStatus();

            $status->name = $request->input('name');
            $status->save();        
          
            return Redirect::back()->with('success', $status->name . ' has been added!');

        }

      
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroyFineStatus($id, Request $request)
    {

        $checkStatus = FineStatus::where('id',$id)->first();

        if($checkStatus) {

            $checkStatus->delete();

            return Redirect::back()->with('success', 'Fine Status has been deleted!');

        } else {

            return Redirect::back()->with('warning', 'Invalid status');

        }
    
    }



  /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function destroyPaymentStatus($id, Request $request)
    {

        $checkStatus = PaymentStatus::where('id',$id)->first();

        if($checkStatus) {

            $checkStatus->delete();

            return Redirect::back()->with('success', 'Payment Status has been deleted!');

        } else {

            return Redirect::back()->with('warning', 'Invalid status');

        }
    
    }



     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function resendVerificationMail($id)
    {

        $user = User::find($id);

        UserVerification::send($user, 'Verify your email address...');
        
      
        return Redirect::back()->with('success', 'User has been resent the verification email.');
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function smsTest($id)
    {

        $user = User::where('mobile',$id)->first();

         $user->notify(new SMSBuyerTest($user));

        return 'SMS Sent!';
    
    }



}
