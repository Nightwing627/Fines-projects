<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PublicController extends Controller
{
    
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function privacy()
    {

        $user = Auth::user();

        return view('public.privacy', compact('user'));
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function terms()
    {

        $user = Auth::user();

        return view('public.terms', compact('user'));
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function contact()
    {

        $user = Auth::user();

        return view('public.contact', compact('user'));
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function unverified()
    {

        $user = Auth::user();

        return view('public.unverified', compact('user'));
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function notapproved()
    {

        $user = Auth::user();

        return view('public.notapproved', compact('user'));
    
    }





}
