<?php

namespace App\Http\Controllers;

use App\IdnumberImports;
use Illuminate\Http\Request;

class IdnumberImportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\IdnumberImports  $idnumberImports
     * @return \Illuminate\Http\Response
     */
    public function show(IdnumberImports $idnumberImports)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\IdnumberImports  $idnumberImports
     * @return \Illuminate\Http\Response
     */
    public function edit(IdnumberImports $idnumberImports)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\IdnumberImports  $idnumberImports
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, IdnumberImports $idnumberImports)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\IdnumberImports  $idnumberImports
     * @return \Illuminate\Http\Response
     */
    public function destroy(IdnumberImports $idnumberImports)
    {
        //
    }
}
