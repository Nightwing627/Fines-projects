<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Fines;
use App\Models\Payments;
use App\Models\PaymentFines;
use App\Models\WalletDebits;
use Illuminate\Http\Request;
use App\Models\WalletCredits;
use App\Models\WalletImports;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Input;
use App\Modules\PayGate\PayGate_PayWeb3;
use Illuminate\Support\Facades\Redirect;

class WalletController extends Controller
{
    
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $user = Auth::user();

        $credits = WalletCredits::where('user_id',$user->id)->get();
        $debits = WalletDebits::where('user_id',$user->id)->get();

        return view('wallet.index', compact('user', 'credits', 'debits'));
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function activate($id)
    {

        $user = User::find($id);

        $user->has_wallet = 1;
        $user->save();        
      
        return Redirect::back()->with('success', 'Your Wallet has been activated!');
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function deactivate($id)
    {

        $user = User::find($id);

        $user->has_wallet = 0;
        $walletAmount = $user->wallet_balance;

        $user->save();        
      
        return Redirect::back()->with('success', 'Your Wallet has been deactivated. Your remaing balance of R' . $walletAmount . ' is still available if you re-activate your wallet.');
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function purchase()
    {

        $user = Auth::user();

        return view('wallet.purchase', compact('user'));
    
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function purchase_create(Request $request)
    {


        if($request->input('amount')) {

            $user = Auth::user();
        
            // save a new wallet credit transaction
            $credit = New WalletCredits();
            $credit->user_id = $user->id;
            $credit->amount = $request->input('amount') + 10;
            $credit->save();

            return redirect()->route('wallet-payment-step2',$credit->uuid);
            
        } else {

            return Redirect::back()->with('warning', 'Please enter a credit amount!');

        }

    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment_step2($uuid)
    {

        $user = Auth::user();
        $payment = WalletCredits::uuid($uuid);
        $amount = $payment->amount;
        $nowtime = now();
        $return_url = "http://ffw.finesupport.co.za/wallet/payment/callback";
        $encryption_key = 'secret';
        $reference = $user->id_number;

        $mandatoryFields = array(
            'PAYGATE_ID'        => filter_var('1021845100016', FILTER_SANITIZE_STRING),
            'REFERENCE'         => filter_var($reference, FILTER_SANITIZE_STRING),
            'AMOUNT'            => filter_var($amount, FILTER_SANITIZE_NUMBER_INT),
            'CURRENCY'          => filter_var('ZAR', FILTER_SANITIZE_STRING),
            'RETURN_URL'        => filter_var($return_url, FILTER_SANITIZE_URL),
            'TRANSACTION_DATE'  => filter_var($nowtime, FILTER_SANITIZE_STRING),
            'LOCALE'            => filter_var('en-za', FILTER_SANITIZE_STRING),
            'COUNTRY'           => filter_var('ZAF', FILTER_SANITIZE_STRING),
            'EMAIL'             => filter_var($user->email, FILTER_SANITIZE_EMAIL)
        );
    
        $optionalFields = array(
            'PAY_METHOD'        => (isset($_POST['PAY_METHOD']) ? filter_var($_POST['PAY_METHOD'], FILTER_SANITIZE_STRING) : ''),
            'PAY_METHOD_DETAIL' => (isset($_POST['PAY_METHOD_DETAIL']) ? filter_var($_POST['PAY_METHOD_DETAIL'], FILTER_SANITIZE_STRING) : ''),
            'NOTIFY_URL'        => (isset($_POST['NOTIFY_URL']) ? filter_var($_POST['NOTIFY_URL'], FILTER_SANITIZE_URL) : ''),
            'USER1'             => (isset($_POST['USER1']) ? filter_var($_POST['USER1'], FILTER_SANITIZE_URL) : ''),
            'USER2'             => (isset($_POST['USER2']) ? filter_var($_POST['USER2'], FILTER_SANITIZE_URL) : ''),
            'USER3'             => (isset($_POST['USER3']) ? filter_var($_POST['USER3'], FILTER_SANITIZE_URL) : ''),
            'VAULT'             => (isset($_POST['VAULT']) ? filter_var($_POST['VAULT'], FILTER_SANITIZE_NUMBER_INT) : ''),
            'VAULT_ID'          => (isset($_POST['VAULT_ID']) ? filter_var($_POST['VAULT_ID'], FILTER_SANITIZE_STRING) : '')
        );

        $data = array_merge($mandatoryFields, $optionalFields);

        // Set the session vars once we have cleaned the inputs
        $_SESSION['pgid']      = $data['PAYGATE_ID'];
        $_SESSION['reference'] = $data['REFERENCE'];
        $_SESSION['key']       = $encryption_key;

        //process the payment
        $PayWeb3 = new PayGate_PayWeb3();
        $PayWeb3->setEncryptionKey($encryption_key);
        $PayWeb3->setInitiateRequest($data);
        $returnData = $PayWeb3->doInitiate();

        $isValid = $PayWeb3->validateChecksum($PayWeb3->initiateResponse);

        // if we get a valid response back, continue
        if($isValid){ 
    
            $request_id = $PayWeb3->processRequest['PAY_REQUEST_ID'];
            $checksum = $PayWeb3->processRequest['CHECKSUM'];

            // update the payment with the response data
            $payment->pay_request_id =  $request_id;
            $payment->pay_checksum =  $checksum;
            $payment->comment = "Paid by " . $reference;
            $payment->save();

            // now process the payment
            $responseResults = array(
                'PAY_REQUEST_ID' => $request_id,
                'CHECKSUM' => $checksum,
            );

            $responseData = array_merge($mandatoryFields, $optionalFields,$responseResults);
            $url = 'https://secure.paygate.co.za/payweb3/process.trans';


            return view('payments.step2', compact('user', 'payment', 'responseData', 'url'));

          
        } else { // else redirect with the error

            $lastError = $PayWeb3->lastError;
            return Redirect::back()->with('warning', 'There was an issue with your payment: ' . $lastError);
        
        }


    }




   /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function process_payment($uuid, Request $request)
    {

        $user = Auth::user();
        $payment = Payments::uuid($uuid);
    
        // first create new wallet debit
        $debit = New WalletDebits();
        $debit->user_id = $user->id;
        $debit->amount = $payment->amount;
        $debit->payment_id = $payment->id;
        $debit->comment = "Payment for PMT-00" . $payment->id;
        $debit->save();

        // now update the payment itself
        $payment->reference = "Payment made using My Wallet.";
        $payment->status_id = 2;
        $payment->save();

        // now go and update each fine's status!
        $fines = PaymentFines::where('payment_id',$payment->id)->get();

        foreach ($fines as $fine) {

            $getfine = Fines::where('id',$fine->fine_id)->first();
            $getfine->status_id = 3; // fine status - Paid (Awaiting Confirmation)
            $getfine->payment_id = $payment->id;
            $getfine->paid = 1;
            $getfine->save();

        }

        // get the new wallet balance
        $oldWalletAmount = $user->wallet_balance;
        $newWalletAmount = $user->wallet_balance - $debit->amount;

        // update the user's wallet
        $user->wallet_balance = $newWalletAmount;
        $user->save();        
        
        // redirect them to payments page
        return redirect()->route('payments')->with('success',$debit->comment . ' was successful! Your remaining Wallet balance is R' . $user->wallet_balance);
    
    }



/**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payment_process(Request $request)
    {

            // 1 => 'Approved',
            // 2 => 'Declined',
            // 4 => 'Cancelled'

        $PAY_REQUEST_ID = $request->input('PAY_REQUEST_ID');
        $TRANSACTION_STATUS = $request->input('TRANSACTION_STATUS');
        $CHECKSUM = $request->input('CHECKSUM');

        $payment = WalletCredits::where('pay_request_id',$PAY_REQUEST_ID)->first();

        if($payment) {

            if($TRANSACTION_STATUS == 4) {
                return redirect()->route('payments')->with('warning', 'Your Payment was cancelled!');
            }

            if($TRANSACTION_STATUS == 2) {
                return redirect()->route('payments')->with('warning', 'Your Payment was declined!');
            }


            if($TRANSACTION_STATUS == 1) {

                $payment->status_id = 2;
                $payment->save();

                // get the user
                $balance = $payment->amount;

                $user = User::where('id',$payment->user_id)->first();

                if($user) {
                    // get the new wallet balance
                    $oldWalletAmount = $user->wallet_balance;
                    $newWalletAmount = $user->wallet_balance + $payment->amount;

                    // update the user's wallet
                    $user->wallet_balance = $newWalletAmount;
                    $user->save();        

                    $balance = $user->wallet_balance;

                }

                return redirect()->route('wallet-thanks',$payment->uuid)->with('success', 'Your Payment was successful! Your balance in your Wallet is R' . $balance);
               
            }

        } else {

            return 'no such transaction';
        }

    }




    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function thanks($uuid)
    {

        $user = Auth::user();
        $payment = WalletCredits::where('uuid',$uuid)->first();        
        $customer = User::where('id', $payment->user_id)->first();

        return view('wallet.thankyou', compact('user', 'payment', 'customer'));
    
    }





    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function receipt($uuid)
    {

        $user = Auth::user();
        $payment = WalletCredits::where('uuid',$uuid)->first();        
        $customer = User::where('id', $payment->user_id)->first();

        return view('wallet.receipt', compact('user', 'payment', 'customer'));
    
    }



     /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function importer(Request $request)
    {

        if (Input::hasFile('file')) {

            // create the import
            $attachment = Input::file('file');
            $filename = 'import_' . str_random(20) . '.' . $attachment->getClientOriginalExtension();
            
            $import = New WalletImports();
            $import->file = 'uploads/imports/wallets/' . $filename;
            $import->user_id = Auth::user()->id;
            $import->import_ref = $filename;
            
            $file = $request->file('file')->move(
                base_path() . '/public/uploads/imports/wallets/' , $filename
            );

            $import->save();

            // Process the file import

            Excel::filter('chunk')->load(base_path() . '/public/'. $import->file)->chunk(250, function($results)
            {
    
                    foreach($results as $line)
                    {
    
                        // $import = DB::table('wallet_imports')->orderBy('created_at', 'desc')->first();
    
                        $id_number = $line->identificationnumber;     
                        $amount = $line->amount;     

                        $checkUser = User::where('id_number',$id_number)->first();

                        if($checkUser) {

                            $user = User::where('id_number',$id_number)->first();
                            $balance = $user->wallet_balance;

                            if($amount < $balance) {

                                // add
                                $diff = $balance - $amount;

                                // create a new wallet credit
                                $credit = New WalletCredits();
                                $credit->user_id = $user->id;
                                $credit->amount = $diff;
                                $credit->comment = "Manual adjustment by System Admin";
                                $credit->status_id = 1;
                                $credit->save();

                                // update the user's balance
                                $user->wallet_balance = $amount;    
                                $user->save();

                            } else {

                                // remove
                                $diff = $amount - $balance;

                                  // first create new wallet debit
                                $debit = New WalletDebits();
                                $debit->user_id = $user->id;
                                $debit->amount = $diff;
                                $debit->payment_id = NULL;
                                $debit->comment = "Manual adjustment by System Admin";
                                $debit->save();

                                 // update the user's balance
                                 $user->wallet_balance = $amount;    
                                 $user->save();
                                
                            }

                        }
    
                    }
    
            },
            false
            );



            // $this->dispatch(new ProcessIDImports($import));

            return Redirect::back()->with('success', 'Your import is complete.');
           
        } else {

            return Redirect::back()->with('warning', 'No file selected!');

        }


    }




}
