<?php

namespace App\Http\Controllers;

ini_set('memory_limit', -1);
set_time_limit(0);

use App\Models\User;
use App\Models\Fines;
use App\Models\Imports;
use App\Mail\ImportComplete;
use Illuminate\Http\Request;
use App\Jobs\ProcessFineImports;
use Illuminate\Support\Facades\DB;
use App\Jobs\SendFineNotifications;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Maatwebsite\Excel\Facades\Excel;
use Rap2hpoutre\FastExcel\FastExcel;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;

class ImportController extends Controller
{
    
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function importer(Request $request)
    {

        if (Input::hasFile('file')) {

            // create the import
            $attachment = Input::file('file');
            $filename = 'ffw_import_' . str_random(20) . '.' . $attachment->getClientOriginalExtension();
            
            $import = New Imports();
            $import->file = 'uploads/imports/' . $filename;
            $import->user_id = Auth::user()->id;
            $import->import_ref = $filename;
            
            $file = $request->file('file')->move(
                base_path() . '/public/uploads/imports/' , $filename
            );

            $import->save();

            // Process the file import
            $this->dispatch(new ProcessFineImports($import));
           


            return redirect()->route('admin-imports')->with('success','Your file has been processed. You will receive an email confirmation was the import is complete.');
           
        } else {

            return Redirect::back()->with('warning', 'No file selected!');

        }


    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function notify_customers()
    {

        // now lets send out the user notifications
        $userList = User::all();

        // first collect only users that have a fines count
        $users = collect();

        foreach($userList as $u) {
            $theuser = User::where('id', $u->id)->first();
            $finesCount = $theuser->fines->count();
            if($finesCount == 0) {
            } else {
                $users->push($theuser);
            }
        }

     
         $this->dispatch(new SendFineNotifications($users));

         return redirect()->route('admin-imports')->with('success','Customer Notifications have been sent!');
           
    }





    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function exporter(Request $request)
    {

        // $fines = Fines::orderBy('created_at', 'DESC')->get();
        // (new FastExcel($fines))->export('fines.csv');

        return (new FastExcel(Fines::all()))->download('all_fines.csv');

    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function userExporter(Request $request)
    {

        return (new FastExcel(User::all()))->download('all_users.csv');

    }



}
