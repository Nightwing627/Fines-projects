<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Models\IDList;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Notifications\UserRegistered;
use App\Mail\RegistrationNotification;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Jrean\UserVerification\Traits\VerifiesUsers;
use Jrean\UserVerification\Facades\UserVerification;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    use VerifiesUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => ['getVerification', 'getVerificationError']]);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'first_name'  => 'required|string|max:255',
            'last_name'   => 'required|string|max:255',
            'email'       => 'required|string|email|max:255|unique:users',
            'id_number'   => 'required|string|max:255|unique:users',
            'mobile'      => 'required|string|max:255',
            'password'    => 'required|string|min:6|confirmed',
            'accept'      => 'required',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        $user = User::create([
            'first_name'    => $data['first_name'],
            'last_name'     => $data['last_name'],
            'name'          => $data['first_name'] . ' ' . $data['last_name'],
            'email'         => $data['email'],
            'id_number'     => $data['id_number'],
            'mobile'        => $data['mobile'],
            'password'      => Hash::make($data['password']),
        ]);

        // $user->notify(new UserRegistered($user));

        Mail::to('finesportal.contact@claimexpert.co.za')
        ->bcc('stan@mustard.agency')
        ->send(new RegistrationNotification($user));
        
            $checkId = IDList::where('id_number', $user->id_number)->first();

            if($checkId) {

                $user->status_id = 1;

            } else {

                $user->status_id = 3;

            }

            $user->save();

        return $user;

    }


        /**
         * Handle a registration request for the application.
         *
         * @param  \Illuminate\Http\Request  $request
         * @return \Illuminate\Http\Response
         */
        public function register(Request $request)
        {
            $this->validator($request->all())->validate();

            $user = $this->create($request->all());

            event(new Registered($user));

            $this->guard()->login($user);

            UserVerification::generate($user);

            UserVerification::send($user, 'Verify your email address...');

            return $this->registered($request, $user)
                            ?: redirect($this->redirectPath());
        }
    
}
