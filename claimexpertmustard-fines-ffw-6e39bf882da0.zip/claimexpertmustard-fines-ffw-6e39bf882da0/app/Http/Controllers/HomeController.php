<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Fines;
use App\Models\Payments;
use App\Models\PaymentFines;
use Illuminate\Http\Request;
use Oversee\PayGate\PayGateWeb;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }



    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function status()
    {

        if (Auth::user()->isAdmin()) {

            return redirect()->route('admin-dashboard');
        
        } else {

            return redirect()->route('home');

        }
      
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $user = Auth::user();

        $paymentsMade = Payments::where('id_number',$user->id_number)->where('status_id',2)->sum('amount');
      
        return view('home', compact('user', 'paymentsMade'));
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function fines()
    {

        $user = Auth::user();

        return view('fines.index', compact('user', 'paymentsMade'));
    
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function payments()
    {

        $user = Auth::user();

        $payments = Payments::where('id_number',$user->id_number)->where('status_id',2)->get();
        $payments_pending = Payments::where('id_number',$user->id_number)->where('status_id',1)->get();

        // dd($user->payments);
      
        return view('payments.index', compact('user', 'payments', 'payments_pending'));
    
    }


    

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function profile()
    {

        $user = Auth::user();

        return view('profile', compact('user'));
    
    }



 /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function profile_update($id, Request $request)
    {


        $user = User::find($id);
        $loggedUser = Auth::user();


        if($loggedUser->id === $user->id) {

            $user->name = $request->input('name');
            $user->mobile = $request->input('mobile');
            $user->notify_me = $request->input('notify_me');
        
            $checkEmail = User::where('email',$user->email)->first();
            
            if($checkEmail = $user) {

            } else {

                if($checkEmail) {
                    $user->email = $request->input('email');
                } else {
                    return redirect()->route('profile')->with('warning','That email address is already taken. Please choose another!');
                }

            }


            $checkID = User::where('id_number',$user->id_number)->first();

           
            if($checkID = $user) {

                if($checkID) {
                    $user->id_number = $request->input('id_number');
                } else {
                    return redirect()->route('profile')->with('warning','That ID number is already registered. Please choose another!');
                }

            }


            if($request->input('password')) {
               $user->password = Hash::make($request->input('password'));
            }

            $user->save();

            return redirect()->route('profile')->with('success','Your Profile was updated!');

        } else {

            return redirect()->route('profile')->with('warning','You do not have permission to update this profile!');

        }


    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function wallet()
    {

        $user = Auth::user();

        
        return view('wallet.index', compact('user'));
    
    }


}
