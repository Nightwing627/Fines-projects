<?php

namespace App\Mail;

use App\Models\Imports;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class ImportComplete extends Mailable
{
    use Queueable, SerializesModels;

    public $import;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(Imports $import)
    {
        
        $this->import = $import;

    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
       
        return $this->markdown('emails.admin.importComplete')
                    ->with([
                        'import_ref' => $this->import->import_ref,
                        'date' => $this->import->created_at,
                        'records' => $this->import->records,
                    ]);
    
    }
}
