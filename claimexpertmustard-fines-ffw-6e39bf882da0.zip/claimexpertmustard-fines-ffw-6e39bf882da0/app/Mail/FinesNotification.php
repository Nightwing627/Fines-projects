<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class FinesNotification extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public $count;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($user, $count)
    {
        
        $this->user = $user;
        $this->count = $count;

    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->markdown('emails.users.userFineNotificationSent')
        ->with([
            'name' => $this->user->name,
            'count' => $this->count,
        ]);
    }
}
